'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useSession, signOut } from 'next-auth/react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Shield,
  BarChart3,
  Settings,
  FileText,
  Users,
  ShoppingCart,
  LogOut,
  User,
  Activity,
  ChevronDown,
  Plus,
  Check,
  X,
  ArrowRight,
  DollarSign,
  Menu,
  ChevronRight
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { AIHelper } from '@/components/ai-helper'

interface DashboardLayoutProps {
  children: React.ReactNode
}

interface Workspace {
  id: string
  name: string
  memberCount: number
  role: string
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { data: session } = useSession()
  const pathname = usePathname()
  const [workspaces, setWorkspaces] = useState<Workspace[]>([])
  const [currentWorkspace, setCurrentWorkspace] = useState<Workspace | null>(null)
  const [loading, setLoading] = useState(false)
  const [triedLoading, setTriedLoading] = useState(false)
  const [showDropdown, setShowDropdown] = useState(false)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [isCreating, setIsCreating] = useState(false)
  const [formName, setFormName] = useState('')
  const [formError, setFormError] = useState('')

  const isAdmin = currentWorkspace?.role === 'ADMIN'
  const isDeveloper = session?.user?.email === 'admin@control-room.ai'
  const [isAffiliate, setIsAffiliate] = useState(false)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  // Fix background scrolling and hide scrollbars
  useEffect(() => {
    const style = document.createElement('style')
    style.textContent = `
      html, body {
        background: linear-gradient(135deg, #0a0f1e 0%, #1a1f2e 50%, #0f1419 100%) !important;
        background-attachment: fixed !important;
        overflow-x: hidden !important;
      }
      
      /* Hide scrollbars completely */
      ::-webkit-scrollbar {
        width: 0px !important;
        height: 0px !important;
        background: transparent !important;
      }
      
      /* Firefox */
      html {
        scrollbar-width: none !important;
        overscroll-behavior: none;
      }
      
      /* Hide scrollbars on all elements */
      * {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      
      *::-webkit-scrollbar {
        width: 0px !important;
        height: 0px !important;
        background: transparent !important;
      }
    `
    document.head.appendChild(style)
    
    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style)
      }
    }
  }, [])

  useEffect(() => {
    if (!session?.user?.id) return
    setLoading(true)
    fetch('/api/workspaces')
      .then(r => r.json())
      .then(data => {
        setWorkspaces(data.workspaces || [])
        setCurrentWorkspace(data.currentWorkspace || null)
      })
      .catch(console.error)
      .finally(() => {
        setLoading(false)
        setTriedLoading(true)
      })
  }, [session?.user?.id])

  useEffect(() => {
    if (!session?.user?.id) return
    fetch('/api/affiliate/status')
      .then(r => r.json())
      .then(data => {
        setIsAffiliate(data.isApproved || false)
      })
      .catch(() => setIsAffiliate(false))
  }, [session?.user?.id])

  useEffect(() => {
    if (triedLoading && workspaces.length === 0) {
      setShowCreateModal(true)
    }
  }, [triedLoading, workspaces.length])

  const handleSwitch = async (workspaceId: string) => {
    try {
      const res = await fetch('/api/workspaces/switch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspaceId })
      })
      if (!res.ok) throw await res.json()
      window.location.reload()
    } catch (err: any) {
      console.error('Switch failed:', err.error || err)
    }
  }

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formName.trim()) {
      setFormError('Workspace name is required')
      return
    }
    setIsCreating(true)
    setFormError('')
    try {
      const createRes = await fetch('/api/workspaces/create', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ name: formName.trim() })
      })
      if (!createRes.ok) throw await createRes.json()
      const { workspace } = await createRes.json()

      const switchRes = await fetch('/api/workspaces/switch', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ workspaceId: workspace.id })
      })
      if (!switchRes.ok) throw await switchRes.json()
      window.location.href = '/dashboard'
    } catch (err: any) {
      console.error('Create workflow failed:', err)
      setFormError(err.error || 'An unexpected error occurred')
    } finally {
      setIsCreating(false)
    }
  }

  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar */}
      <aside className={`${
        sidebarCollapsed ? 'w-0' : 'w-64'
      } text-slate-300 flex flex-col transition-all duration-300 overflow-hidden relative`}
      style={{
        background: "linear-gradient(180deg, rgba(15,23,42,.95), rgba(12,18,36,.95))",
        backdropFilter: "blur(20px)",
        borderRight: "1px solid rgba(71,85,105,.2)",
      }}>
        {!sidebarCollapsed && (
          <div className="p-6 pt-8 border-b border-slate-700/30">
            <div className="relative inline-block">
              <Link href="/" className="select-none group inline-flex items-baseline">
                <span
                  className="text-[13px] uppercase tracking-[0.38em] text-white/95 transition-all duration-200 group-hover:text-slate-100 group-hover:tracking-[0.4em]"
                  style={{ fontWeight: 600 }}
                >
                  CONTROL&nbsp;ROOM
                </span>
                <span
                  className="ml-2 px-1.5 py-[2px] rounded-sm text-[8px] leading-none uppercase tracking-[.15em] font-medium relative -top-0.5"
                  style={{
                    color: "rgba(148,163,184,.8)",
                    background: "linear-gradient(135deg, rgba(71,85,105,.2), rgba(51,65,85,.3))",
                    border: "1px solid rgba(71,85,105,.3)",
                    boxShadow: "0 1px 2px rgba(0,0,0,.1)",
                  }}
                >
                  Beta
                </span>
              </Link>
            </div>
          </div>
        )}
        
        {/* Workspace selector */}
        {!sidebarCollapsed && (
          <div className="p-4 border-b border-slate-700/30 relative">
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="w-full flex items-center justify-between p-3 rounded-lg transition-all duration-200 group hover:scale-[1.01]"
            style={{
              background: "linear-gradient(135deg, rgba(51,65,85,.4), rgba(30,41,59,.5))",
              border: "1px solid rgba(71,85,105,.3)",
              boxShadow: "0 1px 3px rgba(0,0,0,.1), inset 0 1px 0 rgba(255,255,255,.05)",
            }}
          >
            <span className="text-white font-medium group-hover:text-slate-50 transition-colors">{currentWorkspace?.name || 'Loading…'}</span>
            <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-slate-300 transition-colors" />
          </button>
          {showDropdown && (
            <div 
              className="absolute mt-2 w-full rounded-lg shadow-xl z-20 overflow-hidden"
              style={{
                background: "linear-gradient(180deg, rgba(15,23,42,.98), rgba(12,18,36,.98))",
                border: "1px solid rgba(71,85,105,.3)",
                backdropFilter: "blur(20px)",
                boxShadow: "0 10px 25px rgba(0,0,0,.3)",
              }}
            >
              {loading ? (
                <div className="p-3 text-center text-slate-400">Loading…</div>
              ) : (
                <>
                  {workspaces.map(ws => (
                    <button
                      key={ws.id}
                      onClick={() => handleSwitch(ws.id)}
                      className="w-full text-left p-3 hover:bg-slate-700/30 flex justify-between transition-all duration-200 hover:pl-4"
                    >
                      <span className="text-white">{ws.name}</span>
                      {currentWorkspace?.id === ws.id && <Check className="w-4 h-4 text-emerald-400" />}
                    </button>
                  ))}
                  <div className="border-t border-slate-700/40">
                    <button
                      onClick={() => setShowCreateModal(true)}
                      className="w-full text-left p-3 hover:bg-slate-700/30 text-slate-300 transition-all duration-200 hover:text-white hover:pl-4"
                    >
                      <Plus className="inline-block w-4 h-4 mr-2" /> Create Workspace
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
          </div>
        )}
        
        {/* Nav links */}
        {!sidebarCollapsed && (
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {/* Main section */}
          <Link
            href="/dashboard"
            className={cn(
              'flex items-center p-3 rounded-lg font-medium transition-all duration-200 group',
              pathname === '/dashboard' 
                ? 'text-white shadow-lg transform' 
                : 'text-slate-300 hover:text-white hover:translate-x-1'
            )}
            style={pathname === '/dashboard' ? {
              background: "linear-gradient(135deg, rgba(71,85,105,.5), rgba(51,65,85,.6))",
              border: "1px solid rgba(71,85,105,.4)",
              boxShadow: "0 4px 12px rgba(0,0,0,.15), inset 0 1px 0 rgba(255,255,255,.1)",
            } : {}}
          >
            <Activity className="w-5 h-5 mr-3 transition-transform group-hover:scale-110" />
            Dashboard
          </Link>
          
          {/* Divider */}
          <div className="border-t border-slate-700/25 my-4"></div>
          
          {/* Core features section */}
          {[
            { name: 'Tasks', href: '/dashboard/tasks', icon: FileText },
            { name: 'Policies', href: '/dashboard/policies', icon: Shield },
            { name: 'Monitor', href: '/dashboard/monitor', icon: BarChart3 },
            { name: 'Integrations', href: '/dashboard/integrations', icon: Settings },
          ].map(item => {
            const active = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center p-3 rounded-lg font-medium transition-all duration-200 group',
                  active 
                    ? 'text-white shadow-lg transform' 
                    : 'text-slate-300 hover:text-white hover:translate-x-1'
                )}
                style={active ? {
                  background: "linear-gradient(135deg, rgba(71,85,105,.5), rgba(51,65,85,.6))",
                  border: "1px solid rgba(71,85,105,.4)",
                  boxShadow: "0 4px 12px rgba(0,0,0,.15), inset 0 1px 0 rgba(255,255,255,.1)",
                } : {}}
              >
                <item.icon className="w-5 h-5 mr-3 transition-transform group-hover:scale-110" />
                {item.name}
              </Link>
            )
          })}
          
          {/* Divider */}
          <div className="border-t border-slate-700/25 my-4"></div>
          
          {/* Admin section */}
          {isAdmin && (
            <Link
              href="/admin"
              className={cn(
                'flex items-center p-3 rounded-lg font-medium transition-all duration-200 group',
                pathname.startsWith('/admin') 
                  ? 'text-white shadow-lg transform' 
                  : 'text-slate-300 hover:text-white hover:translate-x-1'
              )}
              style={pathname.startsWith('/admin') ? {
                background: "linear-gradient(135deg, rgba(71,85,105,.5), rgba(51,65,85,.6))",
                border: "1px solid rgba(71,85,105,.4)",
                boxShadow: "0 4px 12px rgba(0,0,0,.15), inset 0 1px 0 rgba(255,255,255,.1)",
              } : {}}
            >
              <Users className="w-5 h-5 mr-3 transition-transform group-hover:scale-110" />
              Admin Panel
            </Link>
          )}
          
          {isDeveloper && (
            <Link
              href="/developer"
              className={cn(
                'flex items-center p-3 rounded-lg font-medium transition-all duration-200 group',
                pathname.startsWith('/developer') 
                  ? 'text-emerald-100 shadow-lg transform' 
                  : 'text-slate-300 hover:text-emerald-200 hover:translate-x-1'
              )}
              style={pathname.startsWith('/developer') ? {
                background: "linear-gradient(135deg, rgba(16,185,129,.15), rgba(5,150,105,.2))",
                border: "1px solid rgba(16,185,129,.3)",
                boxShadow: "0 4px 12px rgba(16,185,129,.1), inset 0 1px 0 rgba(16,185,129,.1)",
              } : {}}
            >
              <Shield className="w-5 h-5 mr-3 transition-transform group-hover:scale-110" />
              Developer Panel
            </Link>
          )}
          </nav>
        )}
        
        {/* Marketplace and Affiliate Dashboard above profile */}
        {!sidebarCollapsed && (
          <div className="px-4 pb-4 space-y-1">
          {isAffiliate && (
            <Link
              href="/dashboard/affiliate"
              className={cn(
                'flex items-center p-3 rounded-lg font-medium transition-all duration-200',
                pathname === '/dashboard/affiliate' 
                  ? 'bg-slate-700/50 text-white border border-slate-600/50 shadow-sm' 
                  : 'hover:bg-slate-800/30 text-slate-300 hover:text-white'
              )}
            >
              <DollarSign className="w-5 h-5 mr-3" />
              Affiliate Dashboard
            </Link>
          )}
          </div>
        )}
        
        {/* Profile and Settings */}
        {!sidebarCollapsed && (
          <div className="p-4 border-t border-slate-800/50">
          <div className="flex items-center mb-3 p-2 rounded-lg hover:bg-slate-800/30 transition-colors duration-200">
            <div className="w-8 h-8 rounded-full bg-slate-700/60 border border-slate-600/50 p-1 mr-3 flex items-center justify-center">
              <User className="w-4 h-4 text-slate-300" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{session?.user?.name}</p>
              <p className="text-slate-400 text-xs truncate">
                {currentWorkspace?.role || session?.user?.role}
              </p>
            </div>
          </div>
          <Link
            href="/dashboard/settings"
            className={cn(
              'flex items-center p-3 rounded-lg font-medium transition-all duration-200 w-full',
              pathname === '/dashboard/settings' 
                ? 'bg-slate-700/50 text-white border border-slate-600/50 shadow-sm' 
                : 'hover:bg-slate-800/30 text-slate-300 hover:text-white'
            )}
          >
            <Settings className="w-4 h-4 mr-3" />
            Settings
          </Link>
          </div>
        )}
      </aside>
      
      {/* Main */}
      <main className="flex-1 flex flex-col overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #0a0f1e 0%, #1a1f2e 50%, #0f1419 100%)',
      }}>
        {/* Top bar - only show when sidebar is collapsed */}
        {sidebarCollapsed && (
          <div className="bg-slate-900/80 border-b border-slate-800/50 p-4 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSidebarCollapsed(false)}
                  className="border-slate-700/50 hover:bg-slate-800/50 text-white"
                >
                  <Menu className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        )}
        
        {/* Page content */}
        <div className="flex-1 overflow-y-auto p-6">
          {React.isValidElement(children)
            ? React.cloneElement(children as React.ReactElement, {
                currentWorkspace,
                workspaces,
                isAdmin,
                session,
              })
            : children}
        </div>
      </main>
      
      {/* Create Workspace Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-30 p-4">
          <div className="bg-slate-900/95 border border-slate-700/50 p-6 rounded-lg w-full max-w-md backdrop-blur-sm">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl text-white font-semibold">Create Workspace</h2>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreate}>
              <div className="mb-4">
                <Label htmlFor="ws-name" className="text-slate-300">Name *</Label>
                <Input
                  id="ws-name"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  disabled={isCreating}
                  className="mt-1 bg-slate-800/50 border-slate-700/50 text-white focus:border-slate-600"
                />
              </div>
              {formError && <p className="text-red-400 mb-4 text-sm">{formError}</p>}
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateModal(false)}
                  disabled={isCreating}
                  className="border-slate-700/50 hover:bg-slate-800/50"
                >Cancel</Button>
                <Button 
                  type="submit" 
                  disabled={isCreating || !formName.trim()}
                  className="bg-slate-700 hover:bg-slate-600 border-slate-600"
                >
                  {isCreating ? 'Creating…' : (
                    <>
                      Create <ArrowRight className="w-4 h-4 ml-1"/>
                    </>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* AI Helper */}
      <AIHelper />
    </div>
  )
}
