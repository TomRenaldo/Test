'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  MessageSquare,
  X,
  Send,
  Bot,
  User,
  Loader2,
  Settings,
  AlertTriangle,
  CheckCircle,
  FileText,
  BarChart3,
  Shield,
  Minimize2,
  Maximize2
} from 'lucide-react'

interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: Date
}

interface AISuggestion {
  type: 'policy' | 'metric' | 'task'
  title: string
  description: string
  data: any
}

interface AIHelperProps {}

export function AIHelper({}: AIHelperProps) {
  const { data: session } = useSession()
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [inputMessage, setInputMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const mode = 'explain' as const
  const [sessionId, setSessionId] = useState<string | null>(null)

  // drag
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })

  const messagesEndRef = useRef<HTMLDivElement>(null)

  /* ─────────── UX niceties ─────────── */
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  useEffect(() => {
    if (session?.user?.id && isOpen && !sessionId) {
      initializeChatSession()
    }
  }, [session?.user?.id, isOpen, sessionId])

  useEffect(() => {
    // sensible default corner when first opened
    if (typeof window !== 'undefined' && isOpen && position.x === 0 && position.y === 0) {
      const w = 400, h = 600, pad = 24
      setPosition({ x: window.innerWidth - w - pad, y: window.innerHeight - h - pad })
    }
  }, [isOpen, position.x, position.y])

  /* ─────────── API calls (unchanged behavior) ─────────── */
  async function initializeChatSession() {
    try {
      const response = await fetch('/api/ai-helper/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspaceId: session?.user?.workspaceId })
      })

      if (response.ok) {
        const data = await response.json()
        setSessionId(data.sessionId)

        if (data.messages?.length) {
          setMessages(
            data.messages.map((m: any) => ({ ...m, timestamp: new Date(m.createdAt) }))
          )
        } else {
          const welcome: ChatMessage = {
            id: 'welcome',
            role: 'assistant',
            content:
              `Hello! I’m your Control Room assistant.\n\n` +
              `I’m in Explain Mode: ask about features, creating tasks, policies/metrics, integrations, pricing/TUs, or best practices. I’ll guide you step-by-step.\n\n` +
              `Ready when you are—what would you like to do?`,
            timestamp: new Date()
          }
          setMessages([welcome])
        }
      }
    } catch (err) {
      console.error('Failed to initialize chat session:', err)
    }
  }

  async function sendMessage() {
    if (!inputMessage.trim() || !sessionId || isLoading) return

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: inputMessage.trim(),
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsLoading(true)

    try {
      const response = await fetch('/api/ai-helper/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: userMessage.content,
          mode: 'explain',
          workspaceId: session?.user?.workspaceId
        })
      })

      if (!response.ok) throw new Error('Failed to send message')
      const data = await response.json()

      const assistantMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.message,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, assistantMessage])
    } catch (error) {
      console.error('Failed to send message:', error)
      const errorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: 'Sorry, I hit a snag. Please try again.',
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  async function executeSuggestion() {
    return
  }

  /* ─────────── Drag handling (unchanged behavior) ─────────── */
  function handleMouseDown(e: React.MouseEvent) {
    setIsDragging(true)
    setDragOffset({ x: e.clientX - position.x, y: e.clientY - position.y })
  }
  function handleMouseMove(e: MouseEvent) {
    if (!isDragging) return
    const w = 400, h = isMinimized ? 64 : 600
    const pad = 8
    const newX = Math.min(Math.max(e.clientX - dragOffset.x, pad), window.innerWidth - w - pad)
    const newY = Math.min(Math.max(e.clientY - dragOffset.y, pad), window.innerHeight - h - pad)
    setPosition({ x: newX, y: newY })
  }
  function handleMouseUp() { setIsDragging(false) }
  useEffect(() => {
    if (!isDragging) return
    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, dragOffset])

  /* ─────────── Helpers ─────────── */
  function getSuggestionIcon(type: string) {
    switch (type) {
      case 'policy': return <Shield className="w-4 h-4" />
      case 'metric': return <BarChart3 className="w-4 h-4" />
      case 'task':   return <FileText className="w-4 h-4" />
      default:       return <Settings className="w-4 h-4" />
    }
  }

  if (!session?.user?.id) return null

  return (
    <>
      {/* Floating trigger */}
      {!isOpen && (
        <Button
          aria-label="Open AI Assistant"
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50 hover:scale-[1.07] transition-transform
                     bg-gradient-to-br from-indigo-600 to-violet-600 text-white border border-indigo-400/30"
          size="sm"
        >
          <MessageSquare className="w-6 h-6" />
        </Button>
      )}

      {/* Chat panel */}
      {isOpen && (
        <div
          className={`fixed z-50 ${isMinimized ? 'w-80 h-16' : 'w-[400px] h-[600px]'} transition-[width,height] duration-200`}
          style={{ left: position.x, top: position.y }}
        >
          <Card
            className="h-full flex flex-col overflow-hidden glass-panel
                       border-indigo-400/20 bg-gradient-to-b from-[#0D1324]/95 to-[#0A0F1E]/98"
          >
            {/* Header */}
            <CardHeader
              className="pb-2 cursor-move select-none border-b border-indigo-400/10 bg-[linear-gradient(90deg,rgba(79,106,255,0.15),rgba(138,127,255,0.10))]"
              onMouseDown={handleMouseDown}
            >
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center text-[15px] font-semibold tracking-tight">
                  <span className="inline-flex items-center justify-center w-6 h-6 mr-2 rounded-md
                                   bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                    <Bot className="w-3.5 h-3.5" />
                  </span>
                  AI Assistant
                  <Badge
                    variant="outline"
                    className="ml-2 text-[10px] px-2 py-0.5 rounded-full border border-sky-400/40 text-sky-300"
                  >
                    Explain Mode
                  </Badge>
                </CardTitle>

                <div className="flex items-center gap-1">
                  <Button
                    aria-label={isMinimized ? 'Maximize' : 'Minimize'}
                    size="sm"
                    variant="outline"
                    onClick={() => setIsMinimized(v => !v)}
                    className="h-8 w-8 p-0 border-indigo-400/20 bg-black/10 hover:bg-black/20"
                  >
                    {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
                  </Button>
                  <Button
                    aria-label="Close"
                    size="sm"
                    variant="outline"
                    onClick={() => setIsOpen(false)}
                    className="h-8 w-8 p-0 border-indigo-400/20 bg-black/10 hover:bg-black/20"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

            </CardHeader>

            {/* Body */}
            {!isMinimized && (
              <CardContent className="flex-1 flex flex-col min-h-0 p-3">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                  {messages.map((m) => (
                    <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-[78%] rounded-xl px-3.5 py-2.5 border backdrop-blur
                          ${
                            m.role === 'user'
                              ? 'bg-indigo-600/20 border-indigo-400/30 text-indigo-50 shadow-[0_6px_20px_rgba(79,106,255,0.15)]'
                              : 'bg-slate-800/60 border-slate-500/30 text-slate-100'
                          }`}
                      >
                        <div className="flex items-start gap-2.5">
                          {m.role === 'assistant' ? (
                            <span className="mt-0.5 text-indigo-300"><Bot className="w-4 h-4" /></span>
                          ) : (
                            <span className="mt-0.5 text-indigo-200"><User className="w-4 h-4" /></span>
                          )}
                          <div className="flex-1">
                            <p className="text-[13px] leading-5 whitespace-pre-wrap">{m.content}</p>
                            <p className="text-[10px] text-slate-400 mt-1">{m.timestamp.toLocaleTimeString()}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-slate-800/60 border border-slate-500/30 rounded-xl px-3.5 py-2.5">
                        <div className="flex items-center gap-2 text-slate-300">
                          <Bot className="w-4 h-4 text-indigo-300" />
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span className="text-sm">Thinking…</span>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <form
                  className="mt-3 flex items-center gap-2"
                  onSubmit={(e) => { e.preventDefault(); sendMessage() }}
                >
                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder={'Ask about features, tasks, policies, metrics, integrations, or pricing…'}
                    disabled={isLoading}
                    className="flex-1 h-10 rounded-lg px-3 text-sm text-white placeholder-slate-400
                               bg-[#0B1120] border border-indigo-400/20 focus:outline-none
                               focus:border-indigo-400/50 focus:ring-2 focus:ring-indigo-500/20"
                    aria-label="Type a message"
                  />
                  <Button
                    type="submit"
                    disabled={!inputMessage.trim() || isLoading}
                    className="h-10 px-3 bg-gradient-to-br from-indigo-600 to-violet-600 text-white
                               border border-indigo-400/30 hover:from-indigo-500 hover:to-violet-500"
                    aria-label="Send message"
                  >
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  </Button>
                </form>
              </CardContent>
            )}
          </Card>
        </div>
      )}

    </>
  )
}
