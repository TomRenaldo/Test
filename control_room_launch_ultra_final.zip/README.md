# Control Room — Launch Bundle

## Run
```bash
npm install
npx prisma migrate dev --name launch_prep
npm run dev
# http://localhost:3000
```

## Configure
- Copy `.env.example` → `.env` and fill values.
- Create Stripe Price for TU (1 = $1) and set `STRIPE_TU_PRICE_ID`.
- If you track TU as a Product as well, set `STRIPE_TU_PRODUCT_ID` (used to exclude from affiliate commissions).
- Add Stripe endpoint: `POST /api/webhooks/stripe` and set `STRIPE_WEBHOOK_SECRET`.

## Key Pages
- `/onboarding` — updated slides (copy only; same style vibe).
- `/dashboard/tasks/chat` — plan → TU estimate → run (debits TU).
- `/dashboard/monitor` — KPIs.
- `/dashboard/policies` — NL builder; evaluator cron at `/api/cron/policies/run`.
- `/dashboard/integrations` — Slack/GitHub/Google/Notion + Custom HTTP.
- `/dashboard/settings` — TU balance and top-up (Stripe Checkout).
- `/dashboard/affiliate` — commissions ledger.
- `/helper` — explain-only helper backed by `/helper-ai-docs`.

## Safety
- Global rate limits & CSRF on `/api/*`.
- Stripe webhook signature verification.
- Encrypted OAuth tokens (AES-256).

## Docs
See `/helper-ai-docs/*` for product knowledge, pricing math, policies, security, troubleshooting, and developer reference.
