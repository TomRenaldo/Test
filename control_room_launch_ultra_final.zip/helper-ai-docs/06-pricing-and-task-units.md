# Pricing & Task Units

$29 base (1 WS, 1 user, 10 TU). Add-ons $20/$10. TU=$1. Formula: Raw USD (OpenAI + storage + overhead) ×10 → TU.

## Examples
- TU estimate blocks if insufficient.
