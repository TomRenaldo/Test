# Control Room Helper AI Knowledge Base

Overview
- Control Room uses a single master AI (GPT-4o) that plans, confirms, and executes Tasks. No user-created agents or marketplace.

Tasks
- Flow: user describes → AI plans and repeats back → user confirms/schedules → backend executes via capabilities.
- Costing: preflight shows estimated Task Units (TU); estimator applies 10× markup; TU debit occurs on completion.
- Scheduling: run now or schedule (daily/weekly/custom). Statuses: PENDING, RUNNING, COMPLETED, FAILED, PAUSED, SCHEDULED.
- Logs: real-time task logs, capability inputs/outputs hints, error traces.
- Insufficient TU: server returns HTTP 402 { code: 'INSUFFICIENT_TU' }; UI shows Top Up CTA and retry.

Integrations
- Connect via OAuth or API key; tokens stored encrypted server-side. AI never sees tokens.
- Capabilities run on backend only; inputs validated against schema; results logged with provider/latency/error info.
- Supported examples: slack.postMessage, gmail.send, calendar.createEvent, github.createIssue. Custom endpoints supported via catalog extension.

Policies and Custom Metrics
- Describe in natural language; AI returns a structured proposal and repeat-back summary; user confirms to create/activate.
- Stats cards on Policies: 
  - Active: policies with isActive = true
  - Enforced: policies with isEnforced = true
  - Errors: policies with errorCount &gt; 0
  - Paused: policies with isActive = false
- Enforced indicates the policy is currently applied when relevant triggers occur; Paused means it’s disabled but kept for later use.
- Errors increment when a policy evaluation or effect fails (e.g., invalid target, capability exec error). errorCount is displayed on the Errors card.
- All policy creations/edits produce audit logs with before/after and actor.

Monitor
- KPIs: TU consumed (7d), success/failure counts, avg TU per task, latency (p50/p95), errors by provider.
- Links to drill-down logs for investigations.

Pricing and Task Units
- Base plan: $29/month includes 1 workspace, 1 user, and ~10 TU starter.
- Add-ons: +$20/workspace/month, +$10/user/month.
- Task Units: $1 each, shown to two decimals; charged on execution only.
- Top-ups: instant checkout; if webhooks are delayed, confirm fallback applies on return.

Affiliate
- 50% lifetime commission on subscription and add-ons; TU purchases excluded.
- Dashboard: referrals, itemized commissions, statuses, payout cadence.

Security and Safety
- Never output or request secrets. Tokens and credentials remain server-side.
- Scope minimization for OAuth; rate limits and provider caps enforced.
- Reject harmful or non-compliant requests; follow PII handling rules and require explicit confirmation for external sends.
- Helper AI is explain-only: provides guidance, not execution.

FAQ Hints
- “How do I send a Slack message?” → Connect Slack in Integrations, then create a task like “Post ‘hello team’ to #general” and confirm.
- “What happens if I run out of TUs?” → Task blocks with 402 and you’ll see a top-up prompt; retry after top-up.
- “How are policies created?” → Describe what you want; AI proposes a policy; you confirm to activate.
