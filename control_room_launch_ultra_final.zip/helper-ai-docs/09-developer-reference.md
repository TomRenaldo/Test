# Developer Reference

Catalog in lib/capabilities/catalog.ts; key APIs; migrations; configs.
