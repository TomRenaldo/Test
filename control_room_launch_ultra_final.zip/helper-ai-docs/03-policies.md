# Policies

Triggers like `failure_rate > 0.2 over 60m`, `tu_balance < 5` and actions like Slack/email.

## Examples
- If TU < 5, alert #cr-alerts.
