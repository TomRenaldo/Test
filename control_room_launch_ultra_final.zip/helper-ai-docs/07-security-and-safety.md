# Security & Safety

Rate limiting, CSRF, webhook signatures, idempotency, encrypted tokens, validated capabilities.
