# Integrations & Capabilities

Server-side capabilities (slack.postMessage, github.createIssue, email.send, http.request, notion.*). Tokens encrypted.

## Examples
- Create Notion page in DB.
