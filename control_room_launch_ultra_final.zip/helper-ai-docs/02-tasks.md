# Tasks

Preflight plans steps and estimates TU; Run debits TU; logs per step.

## Examples
- Post daily summary to #ops at 9am.
