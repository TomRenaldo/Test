# Control Room — Overview

Control Room turns plain-English requests into planned, cost-estimated, audited automations.
