import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const WINDOW_MS = 60_000
const MAX_REQ = 60
const buckets = new Map<string, { count:number, reset:number }>()

function rateLimit(key: string) {
  const now = Date.now()
  let b = buckets.get(key) || { count: 0, reset: now + WINDOW_MS }
  if (now > b.reset) { b = { count: 0, reset: now + WINDOW_MS } }
  b.count += 1
  buckets.set(key, b)
  return b.count <= MAX_REQ
}

function needsCsrf(req: NextRequest) {
  return ['POST','PUT','PATCH','DELETE'].includes(req.method) &&
         req.headers.get('sec-fetch-site') !== 'same-origin'
}

export function middleware(req: NextRequest) {
  // Rate limit per IP per minute
  const ip = req.ip ?? req.headers.get('x-forwarded-for') ?? 'unknown'
  if (!rateLimit(String(ip))) {
    return new NextResponse(JSON.stringify({ error: 'rate_limited' }), { status: 429, headers: { 'content-type': 'application/json' } })
  }

  // CSRF: require header token to match cookie for cross-site requests
  if (needsCsrf(req)) {
    const cookieToken = req.cookies.get('csrfToken')?.value || ''
    const headerToken = req.headers.get('x-csrf-token') || ''
    if (!cookieToken || !headerToken || cookieToken !== headerToken) {
      return new NextResponse(JSON.stringify({ error: 'csrf_rejected' }), { status: 403, headers: { 'content-type': 'application/json' } })
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/api/:path*']
}
