import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const adminPassword = await bcrypt.hash('admin123', 12)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@control-room.ai' },
    update: {},
    create: {
      email: 'admin@control-room.ai',
      name: 'Admin User',
      password: adminPassword,
      role: 'ADMIN',
    },
  })

  const managerPassword = await bcrypt.hash('manager123', 12)
  const manager = await prisma.user.upsert({
    where: { email: 'manager@control-room.ai' },
    update: {},
    create: {
      email: 'manager@control-room.ai',
      name: 'Manager User',
      password: managerPassword,
      role: 'MANAGER',
    },
  })

  const existingAegis = await prisma.workspace.findFirst({ where: { name: 'Aegis HQ' } })
  const aegisWorkspace = existingAegis ?? await prisma.workspace.create({
    data: {
      name: 'Aegis HQ',
      members: {
        create: {
          userId: admin.id,
          role: 'ADMIN'
        }
      }
    }
  })

  const existingBeta = await prisma.workspace.findFirst({ where: { name: 'Beta Ops' } })
  const betaWorkspace = existingBeta ?? await prisma.workspace.create({
    data: {
      name: 'Beta Ops',
      members: {
        create: [
          {
            userId: admin.id,
            role: 'VIEWER'
          },
          {
            userId: manager.id,
            role: 'MANAGER'
          }
        ]
      }
    }
  })

  console.log('Database seeded successfully!')
  console.log(`Created workspaces:`)
  console.log(`- Aegis HQ (${aegisWorkspace.id}) with admin@control-room.ai as ADMIN`)
  console.log(`- Beta Ops (${betaWorkspace.id}) with admin@control-room.ai as VIEWER and manager@control-room.ai as MANAGER`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
