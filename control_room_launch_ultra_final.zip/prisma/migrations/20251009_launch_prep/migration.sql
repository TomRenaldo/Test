CREATE TABLE IF NOT EXISTS "IntegrationToken" (
  "provider" TEXT NOT NULL,
  "workspaceId" TEXT NOT NULL,
  "token" TEXT NOT NULL,
  "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
  PRIMARY KEY ("provider", "workspaceId")
);
CREATE TABLE IF NOT EXISTS "AuditLog" (
  "id" TEXT PRIMARY KEY,
  "workspaceId" TEXT NOT NULL,
  "kind" TEXT NOT NULL,
  "message" TEXT NOT NULL,
  "createdAt" TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "Task_status_createdAt_idx" ON "Task"("status","createdAt");
CREATE INDEX IF NOT EXISTS "Policy_workspace_active_idx" ON "Policy"("workspaceId","active");
