
CREATE TABLE IF NOT EXISTS "BillingAccount" (
  "workspaceId" TEXT PRIMARY KEY,
  "tuBalance" NUMERIC(12,2) NOT NULL DEFAULT 10.00,
  "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS "AffiliateReferral" (
  "id" TEXT PRIMARY KEY,
  "affiliateId" TEXT NOT NULL,
  "referredUserId" TEXT NOT NULL,
  "referredWorkspaceId" TEXT NOT NULL,
  "createdAt" TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS "AffiliateCommission" (
  "id" TEXT PRIMARY KEY,
  "referralId" TEXT NOT NULL,
  "invoiceId" TEXT NOT NULL,
  "amountUSD" NUMERIC(12,2) NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'pending',
  "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
  "lockedAt" TIMESTAMP,
  "paidAt" TIMESTAMP
);
CREATE TABLE IF NOT EXISTS "Policy" (
  "id" TEXT PRIMARY KEY,
  "workspaceId" TEXT NOT NULL,
  "createdBy" TEXT NOT NULL,
  "trigger" TEXT NOT NULL,
  "action" TEXT NOT NULL,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
);
