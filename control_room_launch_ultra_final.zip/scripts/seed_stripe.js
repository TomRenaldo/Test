const fs = require('fs');
const path = require('path');
const Stripe = require('stripe');

(function loadEnvFiles() {
  const root = path.resolve(__dirname, '..');
  for (const fname of ['.env', '.env.local']) {
    const fpath = path.join(root, fname);
    if (!fs.existsSync(fpath)) continue;
    const content = fs.readFileSync(fpath, 'utf8');
    for (const rawLine of content.split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith('#')) continue;
      const idx = line.indexOf('=');
      if (idx === -1) continue;
      const key = line.slice(0, idx).trim();
      const val = line.slice(idx + 1).trim();
      if (key && !(key in process.env)) {
        process.env[key] = val;
      }
    }
  }
})();

async function main() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) {
    throw new Error('STRIPE_SECRET_KEY not set');
  }
  const stripe = new Stripe(key, { apiVersion: '2023-10-16' });

  async function ensureProduct(name, description, metadata = {}) {
    const list = await stripe.products.list({ limit: 100, active: true });
    const existing = list.data.find(p => p.name === name);
    if (existing) {
      const needsUpdate = Object.entries(metadata).some(([k, v]) => existing.metadata?.[k] !== String(v));
      if (needsUpdate) {
        return await stripe.products.update(existing.id, { metadata });
      }
      return existing;
    }
    return await stripe.products.create({ name, description, metadata });
  }

  async function ensurePrice({ productId, unitAmount, currency, recurring, metadata = {}, nickname }) {
    const prices = await stripe.prices.list({ product: productId, active: true, limit: 100 });
    const match = prices.data.find(p => 
      p.unit_amount === unitAmount &&
      p.currency === currency &&
      ((recurring && p.recurring && p.recurring.interval === recurring.interval) ||
       (!recurring && !p.recurring))
    );
    if (match) {
      const needsUpdate =
        (nickname && match.nickname !== nickname) ||
        Object.entries(metadata).some(([k, v]) => match.metadata?.[k] !== String(v));
      if (needsUpdate) {
        return await stripe.prices.update(match.id, { nickname, metadata });
      }
      return match;
    }

    return await stripe.prices.create({
      product: productId,
      unit_amount: unitAmount,
      currency,
      ...(recurring ? { recurring } : {}),
      nickname,
      metadata
    });
  }

  const baseProduct = await ensureProduct('Control Room Base Plan', 'Base monthly plan for Control Room', { item_type: 'BASE_PLAN' });
  const basePrice = await ensurePrice({
    productId: baseProduct.id,
    unitAmount: 2900,
    currency: 'usd',
    recurring: { interval: 'month' },
    nickname: 'Base Plan $29/mo',
    metadata: { item_type: 'BASE_PLAN' }
  });

  const wsProduct = await ensureProduct('Workspace Add-on', 'Additional workspace recurring add-on', { item_type: 'WORKSPACE_ADDON' });
  const wsPrice = await ensurePrice({
    productId: wsProduct.id,
    unitAmount: 2000,
    currency: 'usd',
    recurring: { interval: 'month' },
    nickname: 'Workspace Add-on $20/mo',
    metadata: { item_type: 'WORKSPACE_ADDON' }
  });

  const userProduct = await ensureProduct('User Add-on', 'Additional user recurring add-on', { item_type: 'USER_ADDON' });
  const userPrice = await ensurePrice({
    productId: userProduct.id,
    unitAmount: 1000,
    currency: 'usd',
    recurring: { interval: 'month' },
    nickname: 'User Add-on $10/mo',
    metadata: { item_type: 'USER_ADDON' }
  });

  const tuProduct = await ensureProduct('Task Unit Top-up', 'One-time Task Unit purchase (quantity = TU)', { item_type: 'TU', type: 'tu_topup' });
  const tuPrice = await ensurePrice({
    productId: tuProduct.id,
    unitAmount: 100,
    currency: 'usd',
    recurring: null,
    nickname: 'Task Unit Top-up $1',
    metadata: { item_type: 'TU', type: 'tu_topup' }
  });

  const envPath = path.resolve(__dirname, '..', '.env.local');
  const envLines = {
    STRIPE_BASE_PLAN_PRICE_ID: basePrice.id,
    STRIPE_ADDON_WORKSPACE_PRICE_ID: wsPrice.id,
    STRIPE_ADDON_USER_PRICE_ID: userPrice.id,
    STRIPE_TU_TOPUP_PRICE_ID: tuPrice.id
  };

  let existing = '';
  try {
    existing = fs.readFileSync(envPath, 'utf8');
  } catch {}

  const lines = existing ? existing.split('\n') : [];
  const map = new Map();
  for (const line of lines) {
    if (!line) continue;
    const idx = line.indexOf('=');
    if (idx === -1) continue;
    const k = line.slice(0, idx);
    const v = line.slice(idx + 1);
    map.set(k, v);
  }
  for (const [k, v] of Object.entries(envLines)) {
    map.set(k, v);
  }
  const out = Array.from(map.entries())
    .map(([k, v]) => `${k}=${v}`)
    .join('\n') + '\n';
  fs.writeFileSync(envPath, out, 'utf8');

  console.log('STRIPE_BASE_PLAN_PRICE_ID=' + basePrice.id);
  console.log('STRIPE_ADDON_WORKSPACE_PRICE_ID=' + wsPrice.id);
  console.log('STRIPE_ADDON_USER_PRICE_ID=' + userPrice.id);
  console.log('STRIPE_TU_TOPUP_PRICE_ID=' + tuPrice.id);
  console.log(`Wrote price IDs to ${envPath}`);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
