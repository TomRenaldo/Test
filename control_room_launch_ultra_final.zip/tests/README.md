# Tests

- Add API smoke tests for preflight/run, Stripe webhook signature, policy evaluator.
