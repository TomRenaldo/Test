import crypto from 'crypto'
const KEY = (process.env.ENCRYPTION_SECRET || 'dev_secret').slice(0,32).padEnd(32, '0')
const IV = Buffer.from('00000000000000000000000000000000', 'hex')

export function encrypt(text: string) {
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(KEY), IV)
  let enc = cipher.update(text, 'utf8', 'base64')
  enc += cipher.final('base64')
  return enc
}
export function decrypt(b64: string) {
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(KEY), IV)
  let dec = decipher.update(b64, 'base64', 'utf8')
  dec += decipher.final('utf8')
  return dec
}
