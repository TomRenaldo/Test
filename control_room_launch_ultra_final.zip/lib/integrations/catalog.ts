export type CapabilityDef = {
  id: string
  provider: 'GOOGLE' | 'SLACK' | 'GITHUB' | 'STRIPE' | 'NOTION' | 'TRELLO' | 'HUBSPOT' | 'CUSTOM' | 'ZAPIER' | 'MAKE'
  key: string
  title: string
  description?: string
  inputSchema: any
  safetyScope?: any
  rateLimit?: any
  enabled?: boolean
}

export const CATALOG: CapabilityDef[] = [
  {
    id: 'gmail.send',
    provider: 'GOOGLE',
    key: 'gmail.send',
    title: 'Send Email',
    description: 'Send an email via Gmail',
    inputSchema: {
      type: 'object',
      required: ['to', 'subject', 'text'],
      properties: {
        to: { type: 'string', format: 'email' },
        subject: { type: 'string' },
        text: { type: 'string' },
        html: { type: 'string' }
      }
    },
    safetyScope: { pii: 'allowed-from-user-input', externalSend: true }
  },
  {
    id: 'calendar.createEvent',
    provider: 'GOOGLE',
    key: 'calendar.createEvent',
    title: 'Create Calendar Event',
    inputSchema: {
      type: 'object',
      required: ['title', 'start', 'end'],
      properties: {
        title: { type: 'string' },
        start: { type: 'string', format: 'date-time' },
        end: { type: 'string', format: 'date-time' },
        attendees: { type: 'array', items: { type: 'string', format: 'email' } },
        description: { type: 'string' }
      }
    }
  },
  {
    id: 'slack.postMessage',
    provider: 'SLACK',
    key: 'slack.postMessage',
    title: 'Post Slack Message',
    inputSchema: {
      type: 'object',
      required: ['channel', 'text'],
      properties: {
        channel: { type: 'string' },
        text: { type: 'string' }
      }
    }
  },
  {
    id: 'github.createIssue',
    provider: 'GITHUB',
    key: 'github.createIssue',
    title: 'Create GitHub Issue',
    inputSchema: {
      type: 'object',
      required: ['owner', 'repo', 'title'],
      properties: {
        owner: { type: 'string' },
        repo: { type: 'string' },
        title: { type: 'string' },
        body: { type: 'string' },
        labels: { type: 'array', items: { type: 'string' } }
      }
    }
  }
]

export function getCapability(key: string) {
  return CATALOG.find(c => c.key === key || c.id === key)
}

export function listByProvider(provider: CapabilityDef['provider']) {
  return CATALOG.filter(c => c.provider === provider)
}
