
export type Env = {
  DATABASE_URL: string
  NEXTAUTH_URL?: string
  NEXTAUTH_SECRET?: string
  OPENAI_API_KEY?: string
  OPENAI_MODEL?: string
  STRIPE_SECRET_KEY?: string
  STRIPE_TU_PRICE_ID?: string
  STRIPE_TU_PRODUCT_ID?: string
  STRIPE_WEBHOOK_SECRET?: string
  NOTION_CLIENT_ID?: string
  ENCRYPTION_SECRET?: string
}
export function requireEnv(key: keyof Env, optional=false): string {
  const v = process.env[String(key)]
  if (!v && !optional) throw new Error(`Missing required env: ${String(key)}`)
  return v || ''
}
