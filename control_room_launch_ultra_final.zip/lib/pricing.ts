export type PlanConfig = {
  baseMonthlyUSD: number
  includedWorkspaces: number
  includedUsersPerWorkspace: number
  includedTU: number
  addOnWorkspaceUSD: number
  addOnUserUSD: number
  tuUSD: number
}

export const PLAN: PlanConfig = {
  baseMonthlyUSD: 29,
  includedWorkspaces: 1,
  includedUsersPerWorkspace: 1,
  includedTU: 10,
  addOnWorkspaceUSD: 20,
  addOnUserUSD: 10,
  tuUSD: 1
}

export function computeMonthlyTotal(workspaces: number, usersPerWorkspace: number) {
  const extraWs = Math.max(0, workspaces - PLAN.includedWorkspaces)
  const extraUsers = Math.max(0, usersPerWorkspace - PLAN.includedUsersPerWorkspace)
  return PLAN.baseMonthlyUSD + extraWs * PLAN.addOnWorkspaceUSD + extraUsers * PLAN.addOnUserUSD
}
export function getTUPriceId() {
  const v = process.env.STRIPE_TU_TOPUP_PRICE_ID;
  if (!v) throw new Error('Missing STRIPE_TU_TOPUP_PRICE_ID');
  return v;
}

export function getBasePlanPriceId() {
  const v = process.env.STRIPE_BASE_PLAN_PRICE_ID;
  if (!v) throw new Error('Missing STRIPE_BASE_PLAN_PRICE_ID');
  return v;
}

export function getAddonWorkspacePriceId() {
  const v = process.env.STRIPE_ADDON_WORKSPACE_PRICE_ID;
  if (!v) throw new Error('Missing STRIPE_ADDON_WORKSPACE_PRICE_ID');
  return v;
}

export function getAddonUserPriceId() {
  const v = process.env.STRIPE_ADDON_USER_PRICE_ID;
  if (!v) throw new Error('Missing STRIPE_ADDON_USER_PRICE_ID');
  return v;
}
