export const HTTP_ALLOWLIST = ['api.yourcompany.com','hooks.slack.com','api.notion.com'];
