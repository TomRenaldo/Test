import OpenAI from 'openai'
import { estimateTaskUnits } from '@/lib/tu'

type PlanStep = { capability: string; input: any; description?: string }
export type TaskPlan = { steps: PlanStep[]; notes?: string; estimatedTU: number }

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export async function planTask(prompt: string): Promise<TaskPlan> {
  const p = (prompt || '').toLowerCase()
  let steps: PlanStep[] = []

  if (p.includes('slack') || p.includes('message')) {
    steps = [
      {
        capability: 'slack.postMessage',
        input: { channel: '#general', text: prompt },
        description: 'Post a Slack message'
      }
    ]
  } else if (p.includes('email') || p.includes('gmail')) {
    steps = [
      {
        capability: 'gmail.send',
        input: { to: 'example@example.com', subject: 'Automated email', text: prompt },
        description: 'Send an email via Gmail'
      }
    ]
  } else {
    steps = [
      {
        capability: 'plan.explain',
        input: { text: prompt },
        description: 'Explain the task plan'
      }
    ]
  }

  const notes = 'Draft plan generated. Capabilities and inputs must be validated before execution.'
  const estimatedTU = estimateTaskUnits({ openaiUSD: 0.01, storageUSD: 0.001, integrationsUSD: 0.002 })
  return { steps, notes, estimatedTU }
}
