export type ModelPricing = { inputPer1K: number; outputPer1K: number }
export const MODEL_PRICING: Record<string, ModelPricing> = {
  'gpt-4o-mini': { inputPer1K: 0.15, outputPer1K: 0.60 },
  'gpt-4o': { inputPer1K: 5.00, outputPer1K: 15.00 },
}
export type IntegrationUnit = { provider: string; units: number; unitUSD: number }
export function estimateRawCostUSD(params: {
  model: string
  promptTokens: number
  completionTokens: number
  storageKB?: number
  integrations?: IntegrationUnit[]
}) {
  const { model, promptTokens, completionTokens, storageKB = 0, integrations = [] } = params
  const mp = MODEL_PRICING[model] || MODEL_PRICING['gpt-4o-mini']
  const openaiUSD = (promptTokens/1000) * mp.inputPer1K + (completionTokens/1000) * mp.outputPer1K
  const storageUSD = (storageKB/1024) * 0.02
  const integUSD = integrations.reduce((a,c)=> a + c.units * c.unitUSD, 0)
  return openaiUSD + storageUSD + integUSD
}
export function toTaskUnits(rawUSD: number) { return rawUSD * 10 }
