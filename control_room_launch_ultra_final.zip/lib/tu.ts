import { prisma } from '@/lib/prisma'
import { Decimal } from '@prisma/client/runtime/library'

export type TUEstimateInput = {
  openaiUSD: number
  storageUSD?: number
  integrationsUSD?: number
}

export function estimateTaskUnits(input: TUEstimateInput): number {
  const storage = input.storageUSD ?? 0
  const integrations = input.integrationsUSD ?? 0
  const raw = input.openaiUSD + storage + integrations
  const tu = raw * 10
  return Math.round(tu * 100) / 100
}

export async function getTUBalance(workspaceId: string): Promise<number> {
  const ws = await prisma.workspace.findUnique({ where: { id: workspaceId }, select: { tuBalance: true } })
  return Number(ws?.tuBalance ?? 0)
}

export async function creditTU(workspaceId: string, amount: number, refId?: string) {
  await prisma.$transaction([
    prisma.taskUnitLedger.create({
      data: { workspaceId, deltaTU: new Decimal(amount), reason: 'TOP_UP', refId: refId ?? null }
    }),
    prisma.workspace.update({
      where: { id: workspaceId },
      data: { tuBalance: new Decimal(Number((await getTUBalance(workspaceId)) + amount).toFixed(2)) }
    })
  ])
}

export async function debitTU(workspaceId: string, amount: number, refId?: string) {
  const current = await getTUBalance(workspaceId)
  const next = Number((current - amount).toFixed(2))
  await prisma.$transaction([
    prisma.taskUnitLedger.create({
      data: { workspaceId, deltaTU: new Decimal(-amount), reason: 'EXECUTION', refId: refId ?? null }
    }),
    prisma.workspace.update({
      where: { id: workspaceId },
      data: { tuBalance: new Decimal(next) }
    })
  ])
}

export async function requireSufficientTU(workspaceId: string, required: number) {
  const bal = await getTUBalance(workspaceId)
  if (bal < required) {
    throw new Error('INSUFFICIENT_TU')
  }
}
