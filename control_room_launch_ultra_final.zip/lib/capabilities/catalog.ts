export type Capability = {
  id: string
  title: string
  description: string
  inputSchema: Record<string, any>
  safety: { scopes: string[], secrets?: string[] }
  overheadUSD: number
}

export const CAPABILITIES: Capability[] = [
  {
    id: 'slack.postMessage',
    title: 'Post Slack Message',
    description: 'Post a message to a Slack channel',
    inputSchema: { channel: 'string', text: 'string' },
    safety: { scopes: ['chat:write'] },
    overheadUSD: 0.002
  },
  {
    id: 'github.createIssue',
    title: 'Create GitHub Issue',
    description: 'Create an issue in a repository',
    inputSchema: { owner: 'string', repo: 'string', title: 'string', body: 'string?' },
    safety: { scopes: ['repo'] },
    overheadUSD: 0.005
  },
  {
    id: 'email.send',
    title: 'Send Email',
    description: 'Send an email via Gmail or SMTP',
    inputSchema: { to: 'string', subject: 'string', text: 'string?' },
    safety: { scopes: ['gmail.send'] },
    overheadUSD: 0.003
  },
  {
    id: 'http.request',
    title: 'HTTP Request',
    description: 'Call a custom HTTP endpoint',
    inputSchema: { method: 'string', url: 'string', headers: 'object?', body: 'string?' },
    safety: { scopes: ['http:allowlist'] },
    overheadUSD: 0.001
  },
  {
    id: 'notion.createPage',
    title: 'Create Notion Page',
    description: 'Create a page in a Notion database',
    inputSchema: { databaseId: 'string', properties: 'object', children: 'array?' },
    safety: { scopes: ['notion.pages.write'] },
    overheadUSD: 0.004
  },
  {
    id: 'notion.appendBlock',
    title: 'Append Notion Block',
    description: 'Append blocks to an existing Notion block/page',
    inputSchema: { blockId: 'string', children: 'array' },
    safety: { scopes: ['notion.blocks.write'] },
    overheadUSD: 0.004
  },
]
