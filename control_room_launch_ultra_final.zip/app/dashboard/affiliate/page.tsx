import prisma from '@/lib/prisma'
export default async function AffiliateDashboard() {
  const items = await prisma.affiliateCommission.findMany({ orderBy: { createdAt: 'desc' } })
  return <div className="p-6 max-w-5xl mx-auto">
    <h1 className="text-2xl mb-4">Affiliate Commissions</h1>
    <div className="rounded-xl border border-gray-800 overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-black/50"><tr><th className="p-3 text-left">Invoice</th><th className="p-3 text-left">Amount (USD)</th><th className="p-3 text-left">Status</th><th className="p-3 text-left">Created</th></tr></thead>
        <tbody>{items.map((x:any)=>(<tr key={x.id} className="border-t border-gray-800"><td className="p-3">{x.invoiceId}</td><td className="p-3">${Number(x.amountUSD).toFixed(2)}</td><td className="p-3">{x.status}</td><td className="p-3">{new Date(x.createdAt).toLocaleString()}</td></tr>))}</tbody>
      </table>
    </div>
  </div>
}
