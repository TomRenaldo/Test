'use client'

import React, { useEffect, useRef, useState } from 'react'
import { DashboardLayout } from '@/components/dashboard-layout'

export default function TasksPage() {
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [plan, setPlan] = useState<any>(null)
  const [estimate, setEstimate] = useState<number | null>(null)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [insufficient, setInsufficient] = useState(false)
  const [logs, setLogs] = useState<any[]>([])
  const [statusMsg, setStatusMsg] = useState<string | null>(null)
  const [scheduleOption, setScheduleOption] = useState<'now' | 'daily' | 'weekly' | 'custom'>('now')
  const [customDate, setCustomDate] = useState<string>('')
  const [stats, setStats] = useState<{ active: number; completed: number; errors: number; paused: number } | null>(null)

  async function loadStats() {
    try {
      const res = await fetch('/api/tasks/stats')
      const data = await res.json()
      if (res.ok) {
        setStats({
          active: Number(data?.active ?? 0),
          completed: Number(data?.completed ?? 0),
          errors: Number(data?.errors ?? 0),
          paused: Number(data?.paused ?? 0)
        })
      }
    } catch {}
  }

  const pollRef = useRef<any>(null)

  async function preflight() {
    setError(null)
    setResult(null)
    setPlan(null)
    setEstimate(null)
    setInsufficient(false)
    setLogs([])
    if (!input.trim()) return
    setLoading(true)
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input, confirm: false })
      })

      const data = await res.json()
      if (!res.ok) throw new Error(data?.error || 'Failed to estimate')
      setPlan(data.plan)
      setEstimate(data.estimatedTU)
    } catch (e: any) {
      setError(e.message || 'Failed to estimate')
    } finally {
      setLoading(false)
    }
  }

  const taskAction = async (action: 'pause' | 'resume' | 'schedule', schedule?: string) => {
    if (!result?.taskId) return
    setStatusMsg(null)
    const res = await fetch('/api/tasks', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: result.taskId, action, schedule })
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) {
      setStatusMsg(data?.error || 'Action failed')
    } else {
      setStatusMsg('Updated')
    }
  }

  const deleteTask = async () => {
    if (!result?.taskId) return
    setStatusMsg(null)
    const url = new URL('/api/tasks', window.location.origin)
    url.searchParams.set('id', result.taskId)
    const res = await fetch(url.toString(), { method: 'DELETE' })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) {
      setStatusMsg(data?.error || 'Delete failed')
    } else {
      setResult(null)
      setLogs([])
      setStatusMsg('Deleted')
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }

  async function confirm() {
    if (!plan) return
    setLoading(true)
    setError(null)
    setInsufficient(false)
    try {
      let schedule: string | null = null
      if (scheduleOption === 'custom' && customDate) {
        schedule = new Date(customDate).toISOString()
      } else if (scheduleOption === 'daily') {
        schedule = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      } else if (scheduleOption === 'weekly') {
        schedule = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      } else {
        schedule = null
      }

      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input, confirm: true, schedule })
      })
      const data = await res.json()
      if (!res.ok) {
        if (data?.error === 'INSUFFICIENT_TU' || data?.code === 'INSUFFICIENT_TU') {
          setInsufficient(true)
          setError('Insufficient Task Units')
          return
        }
        throw new Error(data?.error || 'Failed to create task')
      }
      setResult(data)
      const taskId = data.taskId
      if (taskId) {
        try {
          const runRes = await fetch(`/api/tasks/${taskId}/run`, { method: 'POST' })
          if (runRes.status === 402) {
            setInsufficient(true)
            setError('Insufficient Task Units')
            return
          }
        } catch {}
        startPolling(taskId)
      }
    } catch (e: any) {
      setError(e.message || 'Failed to create task')
    } finally {
      setLoading(false)
    }
  }

  function startPolling(taskId: string) {
    if (pollRef.current) clearInterval(pollRef.current)
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/tasks/${taskId}/logs`)
        const data = await res.json()
        if (res.ok) {
          setLogs(data.logs || [])
        }
      } catch {}
    }, 1500)
  }

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }, [])

  useEffect(() => {
    loadStats()
  }, [])

  async function topUp(quantity = 10) {
    const res = await fetch('/api/checkout/topup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ quantity })
    })
    const data = await res.json()
    if (res.ok && data?.url) {
      window.location.assign(data.url)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Tasks</h1>
          <p className="text-slate-400 mt-1">Create and manage tasks powered by the master AI.</p>
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-2">
            <div className="rounded-md border border-slate-700/40 bg-slate-900/60 p-3">
              <div className="text-slate-400 text-xs">Active</div>
              <div className="text-white text-xl font-semibold">{stats.active}</div>
            </div>
            <div className="rounded-md border border-slate-700/40 bg-slate-900/60 p-3">
              <div className="text-slate-400 text-xs">Completed</div>
              <div className="text-white text-xl font-semibold">{stats.completed}</div>
            </div>
            <div className="rounded-md border border-slate-700/40 bg-slate-900/60 p-3">
              <div className="text-slate-400 text-xs">Errors</div>
              <div className="text-white text-xl font-semibold">{stats.errors}</div>
            </div>
            <div className="rounded-md border border-slate-700/40 bg-slate-900/60 p-3">
              <div className="text-slate-400 text-xs">Paused</div>
              <div className="text-white text-xl font-semibold">{stats.paused}</div>
            </div>
          </div>
        )}

        </div>

        <div className="rounded-lg border border-slate-700/40 bg-slate-900/60 p-6">
          <div className="flex gap-3">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe what you want the AI to do…"
              className="flex-1 bg-slate-800/60 border border-slate-700/50 rounded-md px-3 py-2 text-slate-200 placeholder-slate-500 outline-none focus:ring-2 focus:ring-slate-500/40"
            />
            <button
              onClick={preflight}
              disabled={loading || !input.trim()}
              className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? 'Thinking…' : 'Estimate'}
            </button>
          </div>

          {error && (
            <div className="mt-3 text-sm text-rose-400">{error}</div>
          )}

          {insufficient && (
            <div className="mt-3 flex items-center gap-3">
              <button
                onClick={() => topUp(10)}
                className="px-3 py-1.5 rounded-md bg-amber-600 hover:bg-amber-500 text-white text-sm"
              >
                Top up 10 TU
              </button>
              <button
                onClick={() => topUp(25)}
                className="px-3 py-1.5 rounded-md bg-amber-700 hover:bg-amber-600 text-white text-sm"
              >
                Top up 25 TU
              </button>
              <a href="/dashboard/settings" className="text-slate-300 text-sm underline">
                Manage in Settings
              </a>
            </div>
          )}

          {plan && (
            <div className="mt-6 space-y-3">
              <div className="text-slate-200 font-medium">Proposed plan</div>
              <pre className="text-slate-300 text-sm bg-slate-800/60 border border-slate-700/50 rounded-md p-3 overflow-auto">
                {JSON.stringify(plan, null, 2)}
              </pre>
              <div className="text-slate-300">
                Estimated Task Units: <span className="font-semibold text-white">{estimate?.toFixed(2)}</span>
              </div>
              <div className="flex flex-col lg:flex-row gap-3 lg:items-center">
                <div className="flex items-center gap-2">
                  <label className="text-slate-300 text-sm">Schedule</label>
                  <select
                    value={scheduleOption}
                    onChange={(e) => setScheduleOption(e.target.value as any)}
                    className="bg-slate-800/60 border border-slate-700/50 rounded-md px-2 py-1 text-slate-200 text-sm"
                  >
                    <option value="now">Now</option>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="custom">Custom</option>
                  </select>
                  {scheduleOption === 'custom' && (
                    <input
                      type="datetime-local"
                      value={customDate}
                      onChange={(e) => setCustomDate(e.target.value)}
                      className="bg-slate-800/60 border border-slate-700/50 rounded-md px-2 py-1 text-slate-200 text-sm"
                    />
                  )}
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={confirm}
                    className="px-4 py-2 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white"
                  >
                    Confirm &amp; {scheduleOption === 'now' ? 'Run' : 'Save'}
                  </button>
                  <button
                    onClick={() => { setPlan(null); setEstimate(null); setInsufficient(false); setError(null); setLogs([]); }}
                    className="px-4 py-2 rounded-md bg-slate-700 hover:bg-slate-600 text-white"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {result?.taskId && (
            <div className="mt-6 space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-slate-200 font-medium">Live logs</div>
                <div className="flex items-center gap-2">
                  <button onClick={() => taskAction('pause')} className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white text-xs">Pause</button>
                  <button onClick={() => taskAction('resume')} className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white text-xs">Resume</button>
                  <button onClick={() => taskAction('schedule', new Date(Date.now() + 24*60*60*1000).toISOString())} className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white text-xs">Schedule +1d</button>
                  <button onClick={deleteTask} className="px-2 py-1 rounded bg-rose-700 hover:bg-rose-600 text-white text-xs">Delete</button>
                </div>
              </div>
              {statusMsg && <div className="text-xs text-slate-400">{statusMsg}</div>}
              <div className="text-xs bg-slate-800/60 border border-slate-700/50 rounded-md p-3 h-56 overflow-auto">
                {logs.length === 0 ? (
                  <div className="text-slate-500">Waiting for logs…</div>
                ) : (
                  logs.map((l) => (
                    <div key={l.id} className="flex items-start gap-2">
                      <span className="text-slate-500">{new Date(l.createdAt).toLocaleTimeString()}</span>
                      <span className={l.level === 'error' ? 'text-rose-400' : 'text-slate-200'}>{l.message}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}
