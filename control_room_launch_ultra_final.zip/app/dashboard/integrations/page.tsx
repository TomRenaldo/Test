
import prisma from '@/lib/prisma'

function Status({connected}:{connected:boolean}){
  return <span className={'text-xs px-2 py-1 rounded ' + (connected ? 'bg-green-900/40 text-green-400' : 'bg-gray-800 text-gray-400')}>{
    connected ? 'Connected' : 'Disconnected'
  }</span>
}

export default async function IntegrationsPage() {
  const ws = 'demo-workspace'
  const tokens = await prisma.integrationToken.findMany({ where: { workspaceId: ws } })
  const has = (p:string)=> tokens.some(t=>t.provider===p)

  const Card = (p:any)=> (
    <div className="rounded-xl border border-gray-800 bg-black/40 p-6 space-y-2">
      <div className="text-lg flex items-center gap-3">
        <span>{p.name}</span>
        <Status connected={p.connected} />
      </div>
      <div className="text-sm text-gray-400">{p.desc}</div>
      <div className="pt-2 flex gap-2">
        <a className="px-4 py-2 rounded bg-purple-600 inline-block" href={p.href}>Connect</a>
        {p.disconnect && <form action={p.disconnect} method="post"><button className="px-3 py-2 rounded bg-gray-700">Disconnect</button></form>}
      </div>
    </div>
  )

  return <div className="p-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    <Card name="Slack" desc="Post messages to channels." href="/api/integrations/slack/connect" connected={has('slack')} />
    <Card name="GitHub" desc="Create issues and track repos." href="/api/integrations/github/connect" connected={has('github')} />
    <Card name="Gmail" desc="Send emails through your account." href="/api/integrations/google/connect" connected={has('gmail')} />
    <Card name="Google Calendar" desc="Create events and reminders." href="/api/integrations/google/calendar/connect" connected={has('google_calendar')} />
    <Card name="Notion" desc="Read/write databases and pages." href="/api/integrations/notion/connect" disconnect="/api/integrations/notion" connected={has('notion')} />
    <Card name="Custom HTTP" desc="Call your own endpoints safely." href="/dashboard/integrations/custom" connected={false} />
  </div>
}
