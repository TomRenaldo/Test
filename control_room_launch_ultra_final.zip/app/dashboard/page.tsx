'use client'

import Link from 'next/link'
import { DashboardLayout } from '@/components/dashboard-layout'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

export default function DashboardPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            <p className="text-gray-400 mt-1">Overview and quick links</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="glass-panel border-blue-500/20">
            <CardHeader>
              <CardTitle className="text-white">Tasks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-400 text-sm">
                Create and manage tasks with the master AI. Schedule, monitor, and audit.
              </p>
              <Link href="/dashboard/tasks">
                <Button className="command-button" size="sm">Go to Tasks</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="glass-panel border-purple-500/20">
            <CardHeader>
              <CardTitle className="text-white">Policies</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-400 text-sm">
                Create and enforce policies via AI with confirmation.
              </p>
              <Link href="/dashboard/policies">
                <Button className="command-button" size="sm">Go to Policies</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="glass-panel border-green-500/20">
            <CardHeader>
              <CardTitle className="text-white">Monitor</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-gray-400 text-sm">
                Monitor TU usage, performance, and errors with drill-down logs.
              </p>
              <Link href="/dashboard/monitor">
                <Button className="command-button" size="sm">Go to Monitor</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
