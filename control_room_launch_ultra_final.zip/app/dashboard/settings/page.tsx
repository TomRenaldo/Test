'use client'
import { useEffect, useState } from 'react'

export default function SettingsPage() {
  const [tu, setTu] = useState<number>(0)
  const [qty, setQty] = useState<number>(10)
  useEffect(()=>{ fetch('/api/tu/balance').then(r=>r.json()).then(d=>setTu(d.tu || 0)) },[])
  const topup = async () => {
    const r = await fetch('/api/tu/topup', { method:'POST', body: JSON.stringify({ quantity: qty }) })
    const d = await r.json(); alert(`Stub checkout: ${d.checkoutUrl}`)
  }
  return <div className="p-6 space-y-4">
    <h1 className="text-2xl">Settings</h1>
    <div className="rounded-lg border border-gray-800 p-4 bg-black/40">
      <div className="text-sm text-gray-400">Task Units</div>
      <div className="text-3xl">{tu.toFixed(2)} TU</div>
      <div className="mt-3 flex items-center gap-2">
        <input className="bg-black/60 border border-gray-700 px-3 py-2 rounded" type="number" value={qty} onChange={e=>setQty(Number(e.target.value))}/>
        <button onClick={topup} className="px-4 py-2 rounded bg-purple-600">Top Up</button>
      </div>
    </div>
  </div>
}
