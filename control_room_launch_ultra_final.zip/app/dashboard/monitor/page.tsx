'use client'
import { useEffect, useState } from 'react'
export default function MonitorPage() {
  const [data, setData] = useState<any>(null)
  useEffect(()=>{ fetch('/api/monitor/metrics').then(r=>r.json()).then(setData) },[])
  const Card = (p:any)=> <div className="p-4 rounded-lg border border-gray-800 bg-black/40"><div className="text-gray-400 text-sm">{p.title}</div><div className="text-3xl">{p.value}</div></div>
  return <div className="p-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    <Card title="Tasks Today" value={data?.tasksToday ?? '—'} />
    <Card title="Failures Today" value={data?.failuresToday ?? '—'} />
    <Card title="TU Spent Today" value={(data?.tuToday ?? 0).toFixed ? (data?.tuToday).toFixed(2) : '—'} />
    <Card title="p50 Latency (ms)" value={data?.p50ms ?? '—'} />
    <Card title="p95 Latency (ms)" value={data?.p95ms ?? '—'} />
  </div>
}
