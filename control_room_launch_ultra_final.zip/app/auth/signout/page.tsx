'use client'

import { signOut } from "next-auth/react"
import { Button } from "@/components/ui/button"

export default function SignOutPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-black text-white">
      <div className="bg-gray-900/60 backdrop-blur-md rounded-2xl p-8 shadow-2xl text-center max-w-sm w-full">
        <h1 className="text-3xl font-semibold mb-4">Sign Out</h1>
        <p className="text-gray-400 mb-6">
          Are you sure you want to sign out of <span className="text-blue-300">Control Room</span>?
        </p>
        <Button
          onClick={() => signOut({ callbackUrl: "/" })}
          className="w-full h-12 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white font-medium rounded-xl shadow-lg"
        >
          Sign Out
        </Button>
      </div>
    </div>
  )
}