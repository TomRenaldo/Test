'use client'
import { useState } from 'react'

export default function HelperPage() {
  const [q,setQ] = useState('')
  const [a,setA] = useState<{hits:any[], text:string}|null>(null)
  const ask = async ()=>{
    const res = await fetch('/api/helper/search', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({ q }) })
    setA(await res.json())
  }
  return (
    <div className="max-w-3xl mx-auto p-6 space-y-4">
      <h1 className="text-2xl">Helper AI (Docs)</h1>
      <p className="text-sm text-gray-400">Explain-only assistant. Answers from Control Room docs.</p>
      <div className="flex gap-2">
        <input className="flex-1 rounded border border-gray-800 bg-black/40 p-2" placeholder="Ask about tasks, pricing, policies, integrations..." value={q} onChange={e=>setQ(e.target.value)} />
        <button onClick={ask} className="px-4 py-2 rounded bg-purple-600">Ask</button>
      </div>
      {a && <div className="rounded-xl border border-gray-800 p-4 bg-black/40">
        <div className="prose prose-invert max-w-none whitespace-pre-wrap">{a.text}</div>
        <div className="mt-4 text-xs text-gray-500">Sources:</div>
        <ul className="text-xs text-gray-500 list-disc pl-5">{a.hits.map((h,i)=>(<li key={i}>{h.file} L{h.line}</li>))}</ul>
      </div>}
    </div>
  )
}
