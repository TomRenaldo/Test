'use client'

import React, { useState, useCallback } from 'react'
import { Navigation } from '@/components/navigation'
import Footer from '@/components/footer'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Mail, Send, Check, Clock, MessageSquare, Sparkles, ArrowRight } from 'lucide-react'

export default function ContactPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({ name: '', email: '', issue: '' })
  const [message, setMessage] = useState('')
  const [messageType, setMessageType] = useState<'success' | 'error' | ''>('')

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage('')
    setMessageType('')

    if (!formData.name || !formData.email || !formData.issue) {
      setMessage('Please fill in all fields.')
      setMessageType('error')
      setIsLoading(false)
      return
    }

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setMessage('Your support ticket has been submitted successfully. We\'ll get back to you soon!')
        setMessageType('success')
        setFormData({ name: '', email: '', issue: '' })
      } else {
        setMessage('Failed to submit your ticket. Please try again or email us directly.')
        setMessageType('error')
      }
    } catch (error) {
      setMessage('An error occurred. Please try again or email us directly.')
      setMessageType('error')
    } finally {
      setIsLoading(false)
    }
  }

  const isFormValid = () => {
    return !!(formData.name && formData.email && formData.issue)
  }

  return (
    <div className="min-h-screen bg-black text-white antialiased flex flex-col">
      <PremiumStyles />
      {/* Ensures Inter is primary everywhere on this page (matches other pages) */}
      <ContactFonts />
      
      {/* Fixed Background Elements */}
      <div className="fixed inset-0 bg-gradient-to-br from-gray-950 via-black to-gray-900 z-0" />
      <div className="fixed inset-0 bg-[linear-gradient(rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:64px_64px] z-0" />
      
      {/* Subtle Accent Glows */}
      <div className="fixed inset-0 opacity-20 z-0">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
      </div>

      <Navigation />
      
      {/* Main Content */}
      <div className="flex-grow relative z-10">
        <main className="px-6 pt-32 pb-16">
          <div className="max-w-7xl mx-auto">
            
            {/* Hero */}
            <header className="text-center mb-12">
              <h1 className="text-4xl md:text-6xl font-light mb-6 tracking-tight">
                <span className="text-white">Get in </span>
                <span className="bg-gradient-to-r from-gray-200 via-blue-200 to-purple-200 bg-clip-text text-transparent">
                  Touch
                </span>
              </h1>
              
              <p className="text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed mb-6">
                We're here to help. Reach out for support, partnerships, or any questions about <span className="text-blue-300">Control Room</span>.
              </p>
            </header>

            {/* Layout */}
            <div className="grid grid-cols-1 xl:grid-cols-5 gap-8 max-w-6xl mx-auto">
              
              {/* Form */}
              <div className="xl:col-span-3">
                <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-2xl shadow-2xl overflow-hidden h-full">
                  <CardHeader className="p-8 border-b border-gray-800">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl flex items-center justify-center">
                        <MessageSquare className="w-6 h-6 text-blue-400" />
                      </div>
                      <div>
                        <CardTitle className="text-2xl font-light text-white">Submit Support Ticket</CardTitle>
                        <p className="text-gray-400 text-sm mt-1">Get help within 24 hours</p>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="p-8">
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <Label className="sleek-label">Full Name *</Label>
                          <Input 
                            id="name" 
                            name="name" 
                            type="text" 
                            placeholder="Your full name" 
                            value={formData.name} 
                            onChange={handleInputChange} 
                            required 
                            className="sleek-input" 
                          />
                        </div>
                        
                        <div className="space-y-3">
                          <Label className="sleek-label">Email Address *</Label>
                          <Input 
                            id="email" 
                            name="email" 
                            type="email" 
                            placeholder="your@email.com" 
                            value={formData.email} 
                            onChange={handleInputChange} 
                            required 
                            className="sleek-input" 
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">Describe Your Issue *</Label>
                        <Textarea 
                          id="issue" 
                          name="issue" 
                          placeholder="Please provide as much detail as possible about your issue..." 
                          value={formData.issue} 
                          onChange={handleInputChange} 
                          required 
                          className="sleek-textarea min-h-[140px]" 
                        />
                      </div>
                      
                      {message && (
                        <div className={`p-4 rounded-xl text-center ${
                          messageType === 'success' 
                            ? 'bg-green-500/10 border border-green-500/30 text-green-300' 
                            : 'bg-red-500/10 border border-red-500/30 text-red-300'
                        }`}>
                          <div className="flex items-center justify-center space-x-2">
                            {messageType === 'success' ? (
                              <Check className="w-4 h-4" />
                            ) : (
                              <div className="w-2 h-2 rounded-full bg-red-400" />
                            )}
                            <span className="text-sm font-medium">{message}</span>
                          </div>
                        </div>
                      )}
                      
                      <Button 
                        type="submit" 
                        disabled={isLoading || !isFormValid()} 
                        className="w-full h-12 text-base font-normal bg-gradient-to-r from-gray-800 to-gray-900 hover:from-gray-700 hover:to-gray-800 text-white border border-gray-700 rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover:border-gray-600 group"
                      >
                        {isLoading ? (
                          <div className="flex items-center justify-center space-x-3">
                            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            <span>Submitting...</span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center space-x-3">
                            <span>Submit Ticket</span>
                            <Send className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5" />
                          </div>
                        )}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>

              {/* Side Panel */}
              <div className="xl:col-span-2 space-y-6">
                
                {/* Business Contact */}
                <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-2xl shadow-2xl overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-lg flex items-center justify-center">
                        <Mail className="w-5 h-5 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-white">Business Inquiries</h3>
                        <p className="text-gray-400 text-xs">Partnerships & enterprise</p>
                      </div>
                    </div>
                    
                    <a 
                      href="mailto:admin@control-room.ai" 
                      className="inline-flex items-center space-x-2 bg-gray-900/50 border border-gray-700 rounded-lg px-4 py-3 text-blue-300 hover:text-white hover:border-blue-400 hover:bg-gray-800/70 transition-all duration-300 font-medium group w-full justify-center text-sm"
                    >
                      <Mail className="w-4 h-4" />
                      <span>admin@control-room.ai</span>
                      <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:translate-x-0.5" />
                    </a>
                  </CardContent>
                </Card>

                {/* Response Times */}
                <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-2xl shadow-2xl overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-lg flex items-center justify-center">
                        <Clock className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-white">Response Times</h3>
                        <p className="text-gray-400 text-xs">What to expect</p>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-300 text-sm">Support Tickets</span>
                        <Badge className="bg-blue-500/10 text-blue-300 border border-blue-500/30 text-xs">
                          24-48h
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-300 text-sm">Business Inquiries</span>
                        <Badge className="bg-purple-500/10 text-purple-300 border border-purple-500/30 text-xs">
                          1-3 days
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Checks */}
                <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-2xl shadow-2xl overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-lg flex items-center justify-center">
                        <Sparkles className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-white">Quick Checks</h3>
                        <p className="text-gray-400 text-xs">Before contacting us</p>
                      </div>
                    </div>
                    
                    <ul className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <Check className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-400 text-sm">Verify billing information</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-400 text-sm">Check our documentation</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-400 text-sm">Try refreshing your browser</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>

      <Footer />
    </div>
  )
}

function PremiumStyles() {
  return (
    <style jsx global>{`
      html, body {
        background-color: #000000;
        scroll-behavior: smooth;
        font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
        height: 100%;
      }
      
      #__next {
        height: 100%;
        display: flex;
        flex-direction: column;
      }
      
      html::-webkit-scrollbar { display: none; }
      html { -ms-overflow-style: none; scrollbar-width: none; }

      /* Sleek Form Elements */
      .sleek-label {
        display: flex !important;
        align-items: center !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        color: #f3f4f6 !important;
        margin-bottom: 8px !important;
        letter-spacing: -0.01em !important;
      }

      .sleek-input, .sleek-textarea {
        background: rgba(17, 24, 39, 0.7) !important;
        border: 1px solid rgba(55, 65, 81, 0.7) !important;
        color: #f9fafb !important;
        border-radius: 12px !important;
        padding: 16px 20px !important;
        font-size: 14px !important;
        font-weight: 400 !important;
        transition: all 0.3s ease !important;
        backdrop-filter: blur(12px) !important;
      }
      
      .sleek-input:focus, .sleek-textarea:focus {
        outline: none !important;
        border-color: rgba(59, 130, 246, 0.8) !important;
        background: rgba(17, 24, 39, 0.9) !important;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
      }

      .sleek-input:hover:not(:focus), .sleek-textarea:hover:not(:focus) {
        border-color: rgba(107, 114, 128, 0.8) !important;
      }
      
      .sleek-input::placeholder, .sleek-textarea::placeholder {
        color: #6b7280 !important;
        opacity: 0.8 !important;
        font-weight: 400 !important;
      }

      button:focus-visible, input:focus-visible, textarea:focus-visible {
        outline: 2px solid rgba(59, 130, 246, 0.5);
        outline-offset: 2px;
      }

      * { transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1); }

      ::selection { background: rgba(59, 130, 246, 0.3); color: white; }
    `}</style>
  )
}

/** Forces Inter to be the primary font everywhere on this page (matches Pricing/Affiliate). */
function ContactFonts() {
  return (
    <style jsx global>{`
      /* Load Inter weights used across the site */
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

      :root { --font-inter: "Inter", -apple-system, BlinkMacSystemFont, sans-serif; }

      html, body, button, input, textarea, select {
        font-family: var(--font-inter) !important;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      h1, h2, h3, h4, h5, h6 { letter-spacing: -0.02em; }
    `}</style>
  )
}
