'use client'
export default function Onboarding(){
  const slides = [
    { title:'Tasks', body:'Describe what you need. We plan steps, estimate TU, ask confirm, then execute with logs.'},
    { title:'Policies', body:'Automate guardrails like failure_rate or low TU and alert via Slack/email.'},
    { title:'Monitor', body:'See throughput, failures, TU spend, latency p50/p95.'},
    { title:'Integrations', body:'Connect Slack, GitHub, Google, Notion and more. Tokens stay encrypted.'},
    { title:'Pricing & TU', body:'$29 base (1 WS, 1 user, 10 TU). Add-ons and $1 TU top-ups. Transparent estimates.'},
    { title:'Safety', body:'Capabilities only, server-side tokens, CSRF & rate limits, signature-verified webhooks.'},
  ]
  return <div className="p-6 max-w-3xl mx-auto space-y-6">
    <h1 className="text-2xl">Welcome to Control Room</h1>
    <div className="space-y-4">
      {slides.map((s,i)=>(
        <div key={i} className="rounded-xl border border-gray-800 bg-black/40 p-4">
          <div className="text-lg">{s.title}</div>
          <div className="text-sm text-gray-400">{s.body}</div>
        </div>
      ))}
    </div>
  </div>
}
