'use client'

import React from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { DollarSign, Users, ArrowRight, Cookie, Award, Edit3, Share2, Check, Zap, TrendingUp, Headphones, BarChart3, CreditCard, Clock, Shield, Target, Gift, ChevronRight } from 'lucide-react'
import Link from 'next/link'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'

export default function AffiliatePage() {
  return (
    <div className="min-h-screen bg-black text-white antialiased">
      <MinimalStyles />
      {/* Ensures Inter is primary, matching the rest of the site */}
      <AffiliateFonts />

      <Navigation />
      
      {/* Subtle Background Grid */}
      <div className="fixed inset-0 bg-[linear-gradient(rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:64px_64px] z-0" />
      
      {/* Minimal Accent Glows */}
      <div className="fixed inset-0 opacity-20 z-0">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
      </div>
      
      <main className="px-6 pt-32 pb-24 relative z-10">
        <div className="max-w-7xl mx-auto">
          
          {/* Minimal Hero Section */}
          <header className="text-center mb-20 max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-3 px-4 py-2 bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-lg text-sm mb-8">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-400"></span>
              </span>
              <span className="text-gray-300 font-medium">Optimized Partnership Program Live</span>
            </div>
            
            {/* NOTE: if you want to fix the size typo, change md:text-7x2 -> md:text-7xl */}
            <h1 className="text-6xl md:text-7x2 font-light tracking-tight mb-8 leading-tight">
              <span className="text-white">Earn </span>
              <span className="bg-gradient-to-r from-gray-200 via-blue-200 to-purple-200 bg-clip-text text-transparent">
                40% Commission
              </span>
            </h1>
            
            <p className="text-xl text-gray-400 mb-12 leading-relaxed max-w-3xl mx-auto font-light">
              Partner with Control Room and earn <span className="text-blue-300">recurring revenue</span> for 6 months on every customer you refer to our AI governance platform.
            </p>
          </header>

          {/* Minimal Key Metrics */}
          <section className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24 max-w-4xl mx-auto">
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-8 text-center group hover:border-gray-700 transition-all duration-300">
              <div className="text-4xl font-light text-blue-300 mb-3 group-hover:scale-105 transition-transform duration-300">40%</div>
              <div className="text-gray-300 font-medium mb-1">Recurring Commission</div>
              <div className="text-sm text-gray-500">For 6 months per referral</div>
            </div>
            
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-8 text-center group hover:border-gray-700 transition-all duration-300">
              <div className="text-4xl font-light text-purple-300 mb-3 group-hover:scale-105 transition-transform duration-300">$100</div>
              <div className="text-gray-300 font-medium mb-1">Annual Plan Bonus</div>
              <div className="text-sm text-gray-500">Extra earnings per sale</div>
            </div>
            
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-8 text-center group hover:border-gray-700 transition-all duration-300">
              <div className="text-4xl font-light text-blue-300 mb-3 group-hover:scale-105 transition-transform duration-300">90</div>
              <div className="text-gray-300 font-medium mb-1">Day Cookie Window</div>
              <div className="text-sm text-gray-500">Extended attribution period</div>
            </div>
          </section>

          {/* How It Works - Clean Timeline */}
          <section className="mb-24 max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-light text-white mb-4">How It Works</h2>
              <p className="text-gray-400 text-lg font-light">Start earning in three simple steps</p>
            </div>
            
            <div className="space-y-12">
              <div className="flex items-start space-x-8 group">
                <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl flex items-center justify-center text-gray-300 text-lg font-light flex-shrink-0 group-hover:border-gray-600 transition-all duration-300">
                  1
                </div>
                <div className="flex-grow pt-1">
                  <h3 className="text-2xl font-light text-white mb-3">Quick Application</h3>
                  <p className="text-gray-400 leading-relaxed">Complete our simple form in under a minute. Our team personally reviews all new partners within 24-48 hours.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-8 group">
                <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl flex items-center justify-center text-gray-300 text-lg font-light flex-shrink-0 group-hover:border-gray-600 transition-all duration-300">
                  2
                </div>
                <div className="flex-grow pt-1">
                  <h3 className="text-2xl font-light text-white mb-3">Share & Promote</h3>
                  <p className="text-gray-400 leading-relaxed">Access your unique referral link, marketing materials, and real-time dashboard to start promoting immediately.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-8 group">
                <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl flex items-center justify-center text-gray-300 text-lg font-light flex-shrink-0 group-hover:border-gray-600 transition-all duration-300">
                  3
                </div>
                <div className="flex-grow pt-1">
                  <h3 className="text-2xl font-light text-white mb-3">Earn Monthly</h3>
                  <p className="text-gray-400 leading-relaxed">Track conversions in real-time and receive automatic monthly payouts via Stripe. No invoicing needed.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Benefits Grid - Minimal Style */}
          <section className="mb-24">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-light text-white mb-4">Why Partners Choose Us</h2>
              <p className="text-gray-400 text-lg font-light">Everything you need to succeed as a Control Room affiliate</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
                <CardContent className="p-0">
                  <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center mb-4">
                    <TrendingUp className="w-6 h-6 text-green-400" />
                  </div>
                  <h3 className="text-lg font-medium text-white mb-3">High Conversion Rates</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">AI governance is in high demand. Our product practically sells itself to the right audience.</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
                <CardContent className="p-0">
                  <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center mb-4">
                    <Zap className="w-6 h-6 text-blue-400" />
                  </div>
                  <h3 className="text-lg font-medium text-white mb-3">Ready-to-Use Assets</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Professional banners, email templates, and conversion-optimized copy provided.</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
                <CardContent className="p-0">
                  <div className="w-12 h-12 bg-purple-500/10 rounded-xl flex items-center justify-center mb-4">
                    <BarChart3 className="w-6 h-6 text-purple-400" />
                  </div>
                  <h3 className="text-lg font-medium text-white mb-3">Real-Time Analytics</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Track clicks, conversions, and earnings instantly with our advanced dashboard.</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
                <CardContent className="p-0">
                  <div className="w-12 h-12 bg-yellow-500/10 rounded-xl flex items-center justify-center mb-4">
                    <Headphones className="w-6 h-6 text-yellow-400" />
                  </div>
                  <h3 className="text-lg font-medium text-white mb-3">Dedicated Support</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Direct access to our partnership team for immediate assistance and strategy guidance.</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
                <CardContent className="p-0">
                  <div className="w-12 h-12 bg-cyan-500/10 rounded-xl flex items-center justify-center mb-4">
                    <Cookie className="w-6 h-6 text-cyan-400" />
                  </div>
                  <h3 className="text-lg font-medium text-white mb-3">90-Day Cookie Window</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Industry-leading attribution period ensures you get credit for your referrals.</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-xl p-6 hover:border-gray-700 transition-all duration-300">
                <CardContent className="p-0">
                  <div className="w-12 h-12 bg-red-500/10 rounded-xl flex items-center justify-center mb-4">
                    <CreditCard className="w-6 h-6 text-red-400" />
                  </div>
                  <h3 className="text-lg font-medium text-white mb-3">Reliable Payouts</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">Automatic monthly payments via Stripe. Minimum payout is $100.</p>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Final CTA */}
          <section className="max-w-4xl mx-auto">
            <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-3xl overflow-hidden">
              <CardContent className="p-12 md:p-16 text-center">
                <h2 className="text-4xl md:text-5xl font-light text-white mb-6">
                  Ready to Start Earning?
                </h2>
                <p className="text-gray-400 mb-10 text-lg max-w-2xl mx-auto font-light leading-relaxed">
                  Join hundreds of successful partners already earning recurring revenue with Control Room.
                </p>
                <Link href="/affiliate/signup">
                  <Button className="h-14 px-10 text-lg font-medium bg-gradient-to-r from-gray-800 to-gray-900 hover:from-gray-700 hover:to-gray-800 text-white border border-gray-700 hover:border-gray-600 rounded-xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl group mb-6">
                    Become a Partner
                    <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-0.5 transition-transform duration-300" />
                  </Button>
                </Link>
                <p className="text-gray-500 text-sm">
                  Questions? 
                  <Link href="/contact" className="text-gray-400 hover:text-white transition-colors ml-1">
                    Contact us
                    <ChevronRight className="w-3 h-3 inline ml-1" />
                  </Link>
                </p>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  )
}

function MinimalStyles() {
  return (
    <style jsx global>{`
      html, body {
        background-color: #000000;
        scroll-behavior: smooth;
        font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
      }
      
      html::-webkit-scrollbar {
        display: none;
      }
      
      html {
        -ms-overflow-style: none;
        scrollbar-width: none;
      }

      /* Minimal Background Effects */
      body {
        background-image: 
          radial-gradient(ellipse at 20% 10%, rgba(59, 130, 246, 0.03), transparent 50%),
          radial-gradient(ellipse at 80% 90%, rgba(147, 51, 234, 0.02), transparent 50%);
      }

      /* Smooth Transitions */
      * {
        transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
      }

      /* Text Selection */
      ::selection {
        background: rgba(59, 130, 246, 0.3);
        color: white;
      }

      /* Enhanced Typography */
      .text-transparent {
        background-clip: text;
        -webkit-background-clip: text;
      }

      /* Focus States */
      button:focus-visible {
        outline: 2px solid rgba(59, 130, 246, 0.5);
        outline-offset: 2px;
      }

      /* Subtle animations */
      @keyframes ping {
        75%, 100% {
          transform: scale(2);
          opacity: 0;
        }
      }

      .animate-ping {
        animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
      }

      /* Reduced Motion Support */
      @media (prefers-reduced-motion: reduce) {
        .animate-ping {
          animation: none;
        }
        
        * {
          transition-duration: 0.01ms !important;
        }
      }
    `}</style>
  )
}

/** Forces Inter to be the primary font everywhere on this page (matches Pricing/others). */
function AffiliateFonts() {
  return (
    <style jsx global>{`
      /* Load Inter weights used across the site */
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

      :root { --font-inter: "Inter", -apple-system, BlinkMacSystemFont, sans-serif; }

      html, body, button, input, textarea, select {
        font-family: var(--font-inter) !important;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      /* Optional: keep headings weighty like other pages */
      h1, h2, h3, h4, h5, h6 { letter-spacing: -0.02em; }
    `}</style>
  )
}