'use client'

import React, { useState, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { DollarSign, Users, TrendingUp, Shield, ArrowLeft, Cookie, CheckCircle2, Sparkles, Zap, Target } from 'lucide-react'
import Link from 'next/link'

interface AffiliateSignupData {
  fullName: string
  email: string
  phoneNumber: string
  address: string
  city: string
  state: string
  zipCode: string
  country: string
  experience: string
  audience: string
  marketingChannels: string
  website?: string
  socialMedia?: string
  agreementAccepted: boolean
}

const affiliateAgreementText = `
Control Room Affiliate Program Agreement
Effective Date: September 22, 2025
Last Updated: September 22, 2025

This Affiliate Program Agreement ("Agreement") governs your participation in the Control Room Affiliate Program ("Program") operated by Control Room Inc. ("Company," "we," "us," or "our"). By registering as an affiliate, you ("Affiliate," "you," or "your") agree to be legally bound by the terms of this Agreement.

1. Program Overview
The Control Room Affiliate Program allows qualified individuals and entities to earn commissions by referring new, paying customers to our AI agent governance platform. Affiliates are compensated for new customer subscriptions generated through their unique referral links.

2. Eligibility
To participate in the Program, you must: (a) be at least 18 years old; (b) have a valid business or personal website, blog, or social media presence relevant to our market; (c) comply with all applicable laws and regulations, including FTC guidelines; and (d) be approved by Company in its sole discretion.

3. Commission Structure
3.1. Commission Rate: Affiliates earn a 40% recurring commission on all subscription payments made by a referred customer for the first six (6) months of their active subscription. The 6-month period begins from the date of the customer's first payment. No commissions shall be earned on payments made after this 6-month period.
3.2. Annual Plan Bonus: Affiliates will receive a one-time bonus of $100 for each referred customer who signs up for and completes payment on an annual subscription plan. This bonus is in addition to the recurring commissions earned on that payment.
3.3. Calculation: Commissions are calculated based on the net revenue received by the Company after any refunds, chargebacks, discounts, and applicable taxes.
3.4. Subscription Modifications: If a referred customer changes their subscription plan during the 6-month commission period, your subsequent commissions for that customer will be calculated based on the new plan's price. Commissions will increase for upgrades and decrease for downgrades. The $100 Annual Plan Bonus will be paid if a customer converts from a monthly to an annual plan within this period.

4. Referral Tracking (Cookie Duration)
Referrals are tracked using cookies. A tracking cookie will be placed in the browser of a user who clicks on your unique affiliate link. You will be credited for a referral if the user signs up for a paid plan within ninety (90) days of their first click on your link, provided it is the last affiliate link they clicked.

5. Payment Terms
5.1. Payouts: Commissions are paid monthly. The minimum payout threshold is $100 USD. Payments are processed via a method agreed upon by both parties within thirty (30) days following the end of the calendar month in which commissions were earned (a "Net-30" schedule). You are responsible for any transaction fees and for providing accurate payment information.
5.2. Refunds and Chargebacks: If a payment from a referred customer is subject to a refund or chargeback, any commission earned on that payment will be voided. The Company reserves the right to deduct the corresponding commission amount from the Affiliate's future payouts.

6. Prohibited Activities
Violation of any of the following terms will result in immediate termination from the Program and forfeiture of any outstanding commissions. Affiliates may not:
(a) Engage in spam, unsolicited email, or any form of indiscriminate advertising.
(b) Use misleading, false, or deceptive advertising.
(c) Bid on Company trademarks (e.g., "Control Room") in any paid search advertising.
(d) Use cookie stuffing, spyware, or other fraudulent techniques to generate commissions.
(e) Use their own affiliate link to purchase a subscription for themselves (self-referrals).
(f) Fail to clearly and conspicuously disclose the affiliate relationship in accordance with FTC guidelines.

7. Affiliate Status and Responsibilities
You agree that you are an independent contractor, and nothing in this Agreement will create any partnership, joint venture, agency, franchise, sales representative, or employment relationship between you and the Company. You are solely responsible for all tax obligations.

8. Termination
Either party may terminate this Agreement at any time, with or without cause. Upon termination, you will be eligible to receive any unpaid commissions that were earned prior to the termination date.

9. Intellectual Property
Company grants you a limited, non-exclusive, non-transferable, revocable license to use our trademarks, logos, and marketing materials ("Licensed Materials") solely for the purpose of promoting Control Room in connection with the Program.

10. Limitation of Liability
The Company's total liability to you under this Agreement shall not exceed the total commissions paid or payable to you. The Company will not be liable for any indirect, incidental, or consequential damages.

11. Modification of Agreement
We reserve the right to modify any of the terms and conditions in this Agreement at any time, in our sole discretion. We will notify you of any changes by email or by posting a notice on our website.

12. Governing Law
This Agreement shall be governed by and construed in accordance with the laws of the State of Delaware, United States.
`;

export default function AffiliateSignupPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [formData, setFormData] = useState<Omit<AffiliateSignupData, 'paymentMethod' | 'paypalEmail' | 'bankAccountNumber' | 'routingNumber'>>({
    fullName: '', email: session?.user?.email || '', phoneNumber: '', address: '', city: '',
    state: '', zipCode: '', country: 'United States', experience: '', audience: '',
    marketingChannels: '', website: '', socialMedia: '', agreementAccepted: false
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (field: keyof typeof formData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async () => {
    if (!formData.agreementAccepted) { setError('You must agree to the Affiliate Agreement to continue'); return; }
    setIsSubmitting(true); setError('');
    try {
      const response = await fetch('/api/affiliate/signup', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, agreementAcceptedAt: new Date().toISOString() })
      });
      if (response.ok) { router.push('/dashboard/affiliate?welcome=true'); }
      else { const data = await response.json(); setError(data.error || 'Failed to submit application'); }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  }

  const isFormValid = () => {
    return !!(formData.fullName && formData.email && formData.phoneNumber && formData.address && formData.city && formData.state && formData.zipCode && formData.country && formData.experience && formData.audience && formData.marketingChannels && formData.agreementAccepted)
  }

  return (
    <div className="min-h-screen bg-black text-white antialiased relative overflow-x-hidden">
      <PremiumStyles />
      
      {/* Minimal Background Effects */}
      <div className="fixed inset-0 bg-gradient-to-br from-gray-950 via-black to-gray-900 z-0" />
      <div className="fixed inset-0 bg-[linear-gradient(rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:64px_64px] z-5" />
      
      {/* Subtle Accent Glows */}
      <div className="fixed inset-0 opacity-20 z-10">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-20">
        {/* Minimal Header */}
        <div className="container mx-auto px-6 py-8">
          <Link href="/affiliate" className="group inline-flex items-center px-4 py-2 text-sm font-medium text-gray-400 hover:text-white bg-gray-900/50 hover:bg-gray-800/70 border border-gray-800 rounded-lg backdrop-blur-sm transition-all duration-300">
            <ArrowLeft className="w-4 h-4 mr-2 transition-transform duration-300 group-hover:-translate-x-1" />
            Back to Program
          </Link>
        </div>

        {/* Minimal Hero Section */}
        <div className="container mx-auto px-6 text-center mb-16">
          <Badge className="px-4 py-1.5 bg-gray-900/80 border border-gray-800 text-gray-300 backdrop-blur-sm mb-6">
            Elite Partnership
          </Badge>
          
          <h1 className="text-5xl md:text-7xl font-light mb-6 tracking-tight">
            <span className="text-white">Become a</span>
            <br />
            <span className="bg-gradient-to-r from-gray-200 via-blue-200 to-purple-200 bg-clip-text text-transparent">
              Control Room Partner
            </span>
          </h1>
          
          <p className="text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed mb-8">
            Join our exclusive partner program and earn <span className="text-blue-300">40% recurring revenue</span> for 6 months on every referral.
          </p>

          {/* Minimal Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6">
              <div className="text-2xl font-light text-blue-300 mb-2">40%</div>
              <div className="text-gray-300 text-sm">Recurring Commission</div>
            </div>
            
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6">
              <div className="text-2xl font-light text-purple-300 mb-2">$100</div>
              <div className="text-gray-300 text-sm">Annual Bonus</div>
            </div>
            
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6">
              <div className="text-2xl font-light text-blue-300 mb-2">90</div>
              <div className="text-gray-300 text-sm">Day Tracking</div>
            </div>
          </div>
        </div>

        {/* Sleek Main Form */}
        <div className="container mx-auto px-6 pb-16">
          <div className="max-w-4xl mx-auto">
            <Card className="bg-gray-900/30 backdrop-blur-sm border border-gray-800 rounded-2xl shadow-2xl overflow-hidden">
              {/* Minimal Header */}
              <CardHeader className="p-12 text-center border-b border-gray-800">
                <CardTitle className="text-3xl font-light text-white mb-4 tracking-tight">
                  Partnership Application
                </CardTitle>
                <CardDescription className="text-gray-400 text-base">
                  Join our exclusive partner program and start earning premium commissions
                </CardDescription>
              </CardHeader>
              
              <CardContent className="p-12">
                <div className="space-y-16">
                  
                  {/* Marketing Profile Section */}
                  <div className="space-y-8">
                    <div className="flex items-center space-x-6">
                      <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl flex items-center justify-center text-gray-300 text-lg font-light">
                        1
                      </div>
                      <div>
                        <h3 className="text-2xl font-light text-white mb-2">Marketing Profile</h3>
                        <p className="text-gray-400">Tell us about your marketing expertise and strategy</p>
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      <div className="space-y-3">
                        <Label className="sleek-label">
                          <Target className="w-4 h-4 mr-2" />
                          Experience with AI/SaaS Marketing *
                        </Label>
                        <Textarea 
                          value={formData.experience} 
                          onChange={(e) => handleChange('experience', e.target.value)} 
                          className="sleek-textarea min-h-[120px]" 
                          placeholder="Describe your experience marketing AI/SaaS products..."
                        />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">
                          <Users className="w-4 h-4 mr-2" />
                          Target Audience *
                        </Label>
                        <Textarea 
                          value={formData.audience} 
                          onChange={(e) => handleChange('audience', e.target.value)} 
                          className="sleek-textarea min-h-[120px]" 
                          placeholder="Detail your target audience demographics and pain points..."
                        />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">
                          <Zap className="w-4 h-4 mr-2" />
                          Primary Marketing Channels *
                        </Label>
                        <Textarea 
                          value={formData.marketingChannels} 
                          onChange={(e) => handleChange('marketingChannels', e.target.value)} 
                          className="sleek-textarea min-h-[120px]" 
                          placeholder="Outline your marketing strategy and channels..."
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <Label className="sleek-label">
                            Website/Blog URL <span className="sleek-optional">Optional</span>
                          </Label>
                          <Input 
                            type="url" 
                            value={formData.website} 
                            onChange={(e) => handleChange('website', e.target.value)} 
                            className="sleek-input" 
                            placeholder="https://yourwebsite.com"
                          />
                        </div>
                        
                        <div className="space-y-3">
                          <Label className="sleek-label">
                            Social Media Profile <span className="sleek-optional">Optional</span>
                          </Label>
                          <Input 
                            value={formData.socialMedia} 
                            onChange={(e) => handleChange('socialMedia', e.target.value)} 
                            className="sleek-input" 
                            placeholder="@username or profile link"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Contact Information Section */}
                  <div className="space-y-8 pt-8 border-t border-gray-800">
                    <div className="flex items-center space-x-6">
                      <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl flex items-center justify-center text-gray-300 text-lg font-light">
                        2
                      </div>
                      <div>
                        <h3 className="text-2xl font-light text-white mb-2">Contact Information</h3>
                        <p className="text-gray-400">Your contact details and business address</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <Label className="sleek-label">Full Name *</Label>
                        <Input value={formData.fullName} onChange={(e) => handleChange('fullName', e.target.value)} className="sleek-input" placeholder="Your full legal name" />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">Email Address *</Label>
                        <Input type="email" value={formData.email} onChange={(e) => handleChange('email', e.target.value)} className="sleek-input" placeholder="your@email.com" />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">Phone Number *</Label>
                        <Input type="tel" value={formData.phoneNumber} onChange={(e) => handleChange('phoneNumber', e.target.value)} className="sleek-input" placeholder="+1 (555) 123-4567" />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">Country *</Label>
                        <Input value={formData.country} onChange={(e) => handleChange('country', e.target.value)} className="sleek-input" placeholder="United States" />
                      </div>
                      
                      <div className="space-y-3 lg:col-span-2">
                        <Label className="sleek-label">Street Address *</Label>
                        <Input value={formData.address} onChange={(e) => handleChange('address', e.target.value)} className="sleek-input" placeholder="123 Main Street, Apt 4B" />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">City *</Label>
                        <Input value={formData.city} onChange={(e) => handleChange('city', e.target.value)} className="sleek-input" placeholder="San Francisco" />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">State/Province *</Label>
                        <Input value={formData.state} onChange={(e) => handleChange('state', e.target.value)} className="sleek-input" placeholder="California" />
                      </div>
                      
                      <div className="space-y-3">
                        <Label className="sleek-label">ZIP/Postal Code *</Label>
                        <Input value={formData.zipCode} onChange={(e) => handleChange('zipCode', e.target.value)} className="sleek-input" placeholder="94102" />
                      </div>
                    </div>
                  </div>

                  {/* Minimal Agreement Section */}
                  <div className="space-y-8 pt-8 border-t border-gray-800">
                    <div className="flex items-center space-x-6">
                      <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl flex items-center justify-center text-gray-300 text-lg font-light">
                        3
                      </div>
                      <div>
                        <h3 className="text-2xl font-light text-white mb-2">Partnership Agreement</h3>
                        <p className="text-gray-400">Review and accept our partnership terms</p>
                      </div>
                    </div>

                    {/* Agreement Highlights */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <DollarSign className="w-4 h-4 text-blue-400" />
                          <span className="text-sm font-medium text-blue-300">Commission</span>
                        </div>
                        <p className="text-gray-400 text-xs">40% recurring for 6 months + $100 annual bonus</p>
                      </div>
                      
                      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <Cookie className="w-4 h-4 text-purple-400" />
                          <span className="text-sm font-medium text-purple-300">Tracking</span>
                        </div>
                        <p className="text-gray-400 text-xs">90-day cookie duration with last-click attribution</p>
                      </div>
                      
                      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <TrendingUp className="w-4 h-4 text-blue-400" />
                          <span className="text-sm font-medium text-blue-300">Payments</span>
                        </div>
                        <p className="text-gray-400 text-xs">Monthly payouts, $100 minimum, Net-30 schedule</p>
                      </div>
                    </div>
                  
                    {/* Agreement Document */}
                    <div className="bg-gray-900/50 border border-gray-800 rounded-xl overflow-hidden">
                      <div className="p-4 border-b border-gray-800 bg-gray-900/30">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Shield className="w-4 h-4 text-blue-400" />
                            <h4 className="text-sm font-medium text-white">Partnership Agreement</h4>
                          </div>
                          <Badge variant="outline" className="text-gray-400 border-gray-700 bg-gray-900/50 text-xs">
                            Effective: September 22, 2025
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="p-6 max-h-64 overflow-y-auto sleek-scrollbar">
                        <pre className="text-xs text-gray-300 whitespace-pre-wrap leading-relaxed font-mono">
                          {affiliateAgreementText}
                        </pre>
                      </div>
                    </div>
                  
                    {/* Minimal Agreement Acceptance */}
                    <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                      <div className="flex items-start space-x-4">
                        <div className="relative mt-1">
                          <input 
                            type="checkbox" 
                            id="agreement-checkbox"
                            checked={formData.agreementAccepted} 
                            onChange={(e) => handleChange('agreementAccepted', e.target.checked)} 
                            className="sr-only"
                          />
                          <label 
                            htmlFor="agreement-checkbox"
                            className={`flex items-center justify-center w-6 h-6 rounded border cursor-pointer transition-all duration-200 ${
                              formData.agreementAccepted 
                                ? 'bg-blue-500 border-blue-400' 
                                : 'border-gray-600 bg-gray-800 hover:border-gray-500'
                            }`}
                          >
                            {formData.agreementAccepted && (
                              <CheckCircle2 className="w-4 h-4 text-white" />
                            )}
                          </label>
                        </div>
                        
                        <div className="flex-1">
                          <Label htmlFor="agreement-checkbox" className="text-base font-normal text-white leading-relaxed cursor-pointer block mb-2">
                            I agree to the terms of the Control Room Affiliate Program Agreement.
                          </Label>
                          <p className="text-gray-400 text-sm leading-relaxed">
                            By checking this box, you confirm acceptance of all terms and conditions outlined above.
                          </p>
                          {formData.agreementAccepted && (
                            <div className="flex items-center space-x-2 mt-3 p-2 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                              <CheckCircle2 className="w-4 h-4 text-blue-400" />
                              <span className="text-blue-300 text-sm">Agreement accepted</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Error Display */}
                  {error && (
                    <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl text-center">
                      <div className="flex items-center justify-center space-x-2 text-red-300">
                        <div className="w-2 h-2 rounded-full bg-red-400" />
                        <span className="text-sm font-medium">{error}</span>
                      </div>
                    </div>
                  )}

                  {/* Sleek Submit Button */}
                  <Button 
                    onClick={handleSubmit}
                    disabled={isSubmitting || !isFormValid()} 
                    className="w-full h-14 text-base font-normal bg-gradient-to-r from-gray-800 to-gray-900 hover:from-gray-700 hover:to-gray-800 text-white border border-gray-700 rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover:border-gray-600 group"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center justify-center space-x-3">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span>Submitting Application...</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center space-x-3">
                        <span>Submit Partnership Application</span>
                        <Sparkles className="w-4 h-4 transition-transform duration-300 group-hover:rotate-12" />
                      </div>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

function PremiumStyles() {
  return (
    <style jsx global>{`
      html, body {
        background-color: #000000;
        scroll-behavior: smooth;
        font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
      }
      
      html::-webkit-scrollbar {
        display: none;
      }
      
      html {
        -ms-overflow-style: none;
        scrollbar-width: none;
      }

      /* Sleek Form Elements */
      .sleek-label {
        display: flex !important;
        align-items: center !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        color: #f3f4f6 !important;
        margin-bottom: 8px !important;
        text-transform: none !important;
        letter-spacing: -0.01em !important;
      }

      .sleek-optional {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: rgba(55, 65, 81, 0.5);
        color: #9ca3af;
        font-size: 11px;
        font-weight: 400;
        padding: 2px 8px;
        border-radius: 6px;
        border: 1px solid rgba(75, 85, 99, 0.3);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-left: 8px;
      }

      .sleek-input, .sleek-textarea {
        background: rgba(17, 24, 39, 0.7) !important;
        border: 1px solid rgba(55, 65, 81, 0.7) !important;
        color: #f9fafb !important;
        border-radius: 12px !important;
        padding: 16px 20px !important;
        font-size: 14px !important;
        font-weight: 400 !important;
        transition: all 0.3s ease !important;
        backdrop-filter: blur(12px) !important;
      }
      
      .sleek-input:focus, .sleek-textarea:focus {
        outline: none !important;
        border-color: rgba(59, 130, 246, 0.8) !important;
        background: rgba(17, 24, 39, 0.9) !important;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
      }

      .sleek-input:hover:not(:focus), .sleek-textarea:hover:not(:focus) {
        border-color: rgba(107, 114, 128, 0.8) !important;
      }
      
      .sleek-input::placeholder, .sleek-textarea::placeholder {
        color: #6b7280 !important;
        opacity: 0.8 !important;
        font-weight: 400 !important;
      }
      
      /* Sleek Scrollbar */
      .sleek-scrollbar::-webkit-scrollbar {
        width: 8px;
      }
      
      .sleek-scrollbar::-webkit-scrollbar-track {
        background: rgba(17, 24, 39, 0.8);
        border-radius: 8px;
      }
      
      .sleek-scrollbar::-webkit-scrollbar-thumb {
        background: rgba(55, 65, 81, 0.8);
        border-radius: 8px;
        border: 2px solid transparent;
        background-clip: padding-box;
      }
      
      .sleek-scrollbar::-webkit-scrollbar-thumb:hover {
        background: rgba(75, 85, 99, 0.8);
      }

      /* Enhanced focus states */
      button:focus-visible, input:focus-visible, textarea:focus-visible {
        outline: 2px solid rgba(59, 130, 246, 0.5);
        outline-offset: 2px;
      }

      /* Smooth transitions */
      * {
        transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
      }
    `}</style>
  )
}
