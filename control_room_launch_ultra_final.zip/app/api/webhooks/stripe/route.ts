import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import prisma from '@/lib/prisma'

export async function POST(req: Request) {
  const body = await req.text()
  const sig = headers().get('stripe-signature') || ''
  const secret = process.env.STRIPE_WEBHOOK_SECRET || ''
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2024-06-20' })
  let event
  try { event = stripe.webhooks.constructEvent(body, sig, secret) }
  catch { return NextResponse.json({ error: 'invalid_signature' }, { status: 400 }) }

  
  // Idempotency: skip if event already processed
  try {
    const already = await prisma.processedEvent.findUnique({ where: { id: event.id } as any })
    if (already) return NextResponse.json({ received: true, idempotent: true })
    await prisma.processedEvent.create({ data: { id: event.id } as any })
  } catch {}

  if (event.type === 'checkout.session.completed') {
    const session: any = event.data.object
    const qty = Number(session?.metadata?.tuQty || 0)
    const workspaceId = String(session?.metadata?.workspaceId || '')
    if (qty > 0 && workspaceId) {
      await prisma.billingAccount.upsert({ where: { workspaceId }, update: { tuBalance: { increment: qty } }, create: { workspaceId, tuBalance: qty } })
    }
  }

  if (event.type === 'invoice.paid') {
    const invoice: any = event.data.object
    const ws = String(invoice?.metadata?.workspaceId || '')
    const tuProduct = process.env.STRIPE_TU_PRODUCT_ID || ''
    let commissionableUSD = 0
    if (invoice?.lines?.data?.length) {
      for (const line of invoice.lines.data) {
        const product = line?.price?.product || ''
        const amountUSD = (line?.amount || 0) / 100
        if (product && tuProduct && product === tuProduct) continue // exclude TU
        commissionableUSD += amountUSD
      }
    }
    if (commissionableUSD > 0 && ws) {
      const referral = await prisma.affiliateReferral.findFirst({ where: { referredWorkspaceId: ws } })
      if (referral) {
        const amount = (commissionableUSD * 0.5)
        await prisma.affiliateCommission.create({
          data: {
            id: crypto.randomUUID(),
            referralId: referral.id,
            invoiceId: invoice.id,
            amountUSD: amount,
            status: 'pending'
          } as any
        })
      }
    }
  }

  return NextResponse.json({ received: true })
}
