import { NextResponse } from 'next/server'
import fs from 'fs'
import path from 'path'

function searchDocs(base:string, q:string) {
  const files = fs.readdirSync(base).filter(f=>f.endsWith('.md'))
  const hits:any[] = []
  const ql = q.toLowerCase()
  for (const f of files) {
    const p = path.join(base, f)
    const text = fs.readFileSync(p, 'utf8')
    const lines = text.split(/\r?\n/)
    lines.forEach((line,idx)=>{
      if (line.toLowerCase().includes(ql)) hits.push({ file: f, line: idx+1, excerpt: line.trim().slice(0,180) })
    })
  }
  const answer = hits.slice(0,6).map(h=>`${h.file}: ${h.excerpt}`).join('\n')
  const fallback = "I searched the Control Room docs and assembled the most relevant excerpts above."
  return { hits, text: answer || fallback }
}

export async function POST(req: Request) {
  const { q='' } = await req.json()
  const base = path.join(process.cwd(), 'helper-ai-docs')
  const result = searchDocs(base, q)
  return NextResponse.json(result)
}
