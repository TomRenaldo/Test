import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import type { AffiliateCommission } from '@prisma/client'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const affiliate = await prisma.affiliate.findUnique({
      where: { userId: session.user.id }
    })

    if (!affiliate || !affiliate.isApproved) {
      return NextResponse.json({ error: 'Not an approved affiliate' }, { status: 403 })
    }

    const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000'
    const referralLink = `${baseUrl}/signup?ref=${affiliate.code}`

    const [commissions, referrals] = await Promise.all([
      prisma.affiliateCommission.findMany({
        where: { affiliateId: affiliate.id },
        orderBy: { cycleAt: 'desc' },
        take: 100
      }) as unknown as Promise<AffiliateCommission[]>,
      (prisma as any).affiliateAttribution.count({
        where: { affiliateId: affiliate.id, active: true }
      }) as Promise<number>
    ])

    const totalEarnings = (commissions as AffiliateCommission[]).reduce((sum: number, c: AffiliateCommission) => {
      return sum + Number(c.amountUSD)
    }, 0)

    const currentMonthStart = new Date()
    currentMonthStart.setDate(1)
    currentMonthStart.setHours(0, 0, 0, 0)

    const currentMonthEarnings = (commissions as AffiliateCommission[])
      .filter((c: AffiliateCommission) => c.cycleAt >= currentMonthStart)
      .reduce((sum: number, c: AffiliateCommission) => sum + Number(c.amountUSD), 0)

    const conversionRate = affiliate.clicks > 0 ? (affiliate.conversions / affiliate.clicks) * 100 : 0

    const nextPayoutDate = (() => {
      const now = new Date()
      const y = now.getUTCFullYear()
      const m = now.getUTCMonth() + 1
      const next = new Date(Date.UTC(m === 12 ? y + 1 : y, m === 12 ? 0 : m, 1, 0, 0, 0))
      return next.toISOString()
    })()

    return NextResponse.json({
      totalClicks: affiliate.clicks,
      totalConversions: affiliate.conversions,
      totalEarnings,
      currentMonthEarnings,
      conversionRate,
      referralCode: affiliate.code,
      referralLink,
      payoutInfo: affiliate.payoutInfo,
      referrals,
      commissions: (commissions as AffiliateCommission[]).map((c: AffiliateCommission) => ({
        id: c.id,
        itemType: c.itemType,
        amountUSD: Number(c.amountUSD),
        percentage: c.percentage,
        status: c.status,
        cycleAt: c.cycleAt,
        workspaceId: c.workspaceId,
        stripeTransferId: c.stripeTransferId
      })),
      nextPayoutDate
    })

  } catch (error) {
    console.error('Affiliate stats error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch affiliate stats' },
      { status: 500 }
    )
  }
}
