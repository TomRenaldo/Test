import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const isTest = process.env.STRIPE_TEST_MODE === 'true' || process.env.NODE_ENV !== 'production'
    if (!isTest) {
      return NextResponse.json({ error: 'Not allowed in production' }, { status: 403 })
    }

    const now = new Date()
    const pending = await prisma.affiliateCommission.findMany({
      where: { status: 'pending', cycleAt: { lte: now } },
      take: 200
    })

    if (pending.length === 0) {
      return NextResponse.json({ updated: 0 })
    }

    const updates = await Promise.all(
      pending.map((c) =>
        prisma.affiliateCommission.update({
          where: { id: c.id },
          data: {
            status: 'paid',
            stripeTransferId: c.stripeTransferId || `test_transfer_${c.id}`
          }
        })
      )
    )

    return NextResponse.json({ updated: updates.length })
  } catch (e) {
    console.error('affiliate settle error', e)
    return NextResponse.json({ error: 'Failed to settle commissions' }, { status: 500 })
  }
}
