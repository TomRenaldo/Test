import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import Stripe from 'stripe'

const stripeSecret = process.env.STRIPE_SECRET_KEY || ''
const stripe = stripeSecret ? new Stripe(stripeSecret, { apiVersion: '2023-10-16' }) : null

export async function POST(request: NextRequest) {
  try {
    const isTest = process.env.NODE_ENV !== 'production'
    if (!isTest) {
      return NextResponse.json({ error: 'Not allowed in production' }, { status: 403 })
    }
    if (!stripe) {
      return NextResponse.json({ error: 'Stripe not configured' }, { status: 500 })
    }

    const now = new Date()
    const pending = await prisma.affiliateCommission.findMany({
      where: { status: 'pending', cycleAt: { lte: now } },
      orderBy: { affiliateId: 'asc' }
    })

    if (pending.length === 0) return NextResponse.json({ transfers: 0, commissions: 0 })

    const byAffiliate = new Map<string, any[]>()
    for (const c of pending as any[]) {
      const arr = byAffiliate.get(c.affiliateId) || []
      arr.push(c)
      byAffiliate.set(c.affiliateId, arr)
    }

    let transfers = 0
    let commissions = 0

    const affiliateIds = Array.from(byAffiliate.keys())
    for (const affiliateId of affiliateIds) {
      const commissionsList = byAffiliate.get(affiliateId) as any[] | undefined
      if (!commissionsList?.length) continue

      const affiliate = await prisma.affiliate.findUnique({ where: { id: affiliateId } })
      if (!affiliate?.payoutInfo) continue
      let connectAccountId: string | undefined
      try {
        const info = typeof affiliate.payoutInfo === 'string' ? JSON.parse(affiliate.payoutInfo) : affiliate.payoutInfo
        connectAccountId = (info as any)?.connectAccountId
      } catch {}
      if (!connectAccountId) continue

      const amountTotal = commissionsList.reduce((sum: number, c: any) => sum + Number(c.amountUSD), 0)
      if (amountTotal <= 0) continue

      const transfer = await stripe.transfers.create({
        amount: Math.round(amountTotal * 100),
        currency: 'usd',
        destination: connectAccountId,
        description: `Affiliate payout (${commissionsList.length} commissions)`
      })

      await prisma.$transaction(
        commissionsList.map((c: any) =>
          prisma.affiliateCommission.update({
            where: { id: c.id },
            data: { status: 'paid', stripeTransferId: transfer.id }
          })
        )
      )

      transfers += 1
      commissions += commissionsList.length
    }

    return NextResponse.json({ transfers, commissions })
  } catch (e) {
    console.error('affiliate payout run error', e)
    return NextResponse.json({ error: 'Failed to run payouts' }, { status: 500 })
  }
}
