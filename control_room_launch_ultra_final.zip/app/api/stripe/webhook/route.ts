import { NextRequest, NextResponse } from 'next/server'
import { headers } from 'next/headers'
import Stripe from 'stripe'
import { prisma } from '@/lib/prisma'
import type { Prisma } from '@prisma/client'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16'
})

const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(request: NextRequest) {
  const body = await request.text()
  const sig = headers().get('stripe-signature')!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, sig, endpointSecret)
  } catch (err: any) {
    console.error(`Webhook signature verification failed.`, err.message)
    return NextResponse.json({ error: 'Webhook signature verification failed' }, { status: 400 })
  }

  try {
    console.log('Stripe webhook received', { type: event.type })
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription
        await handleSubscriptionChange(subscription)
        break
      }
      case 'customer.subscription.deleted': {
        const deletedSubscription = event.data.object as Stripe.Subscription
        await handleSubscriptionCancellation(deletedSubscription)
        break
      }
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        await handleCheckoutCompleted(session)
        break
      }
      case 'invoice.paid': {
        const invoice = event.data.object as Stripe.Invoice
        await handleInvoicePaid(invoice)
        break
      }
      default:
        console.log(`Unhandled event type ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error('Error processing webhook:', error)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}

async function handleSubscriptionChange(subscription: Stripe.Subscription) {
  const customerId = subscription.customer as string

  const user = await prisma.user.findFirst({
    where: {
      subscription: {
        stripeCustomerId: customerId
      }
    }
  })

  if (!user) {
    console.error('User not found for customer:', customerId)
    return
  }

  await prisma.subscription.upsert({
    where: { userId: user.id },
    update: {
      status: subscription.status,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      stripeSubscriptionId: subscription.id
    },
    create: {
      userId: user.id,
      plan: 'PRO',
      status: subscription.status,
      stripeCustomerId: customerId,
      stripeSubscriptionId: subscription.id,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000)
    }
  })
}

async function handleSubscriptionCancellation(subscription: Stripe.Subscription) {
  await prisma.subscription.updateMany({
    where: { stripeSubscriptionId: subscription.id },
    data: { status: 'canceled' }
  })
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  if (session.mode !== 'payment') return
  if (session.metadata?.type !== 'tu_topup') return
  if (session.payment_status && session.payment_status !== 'paid') return

  const qty = Number(session.metadata?.quantity || '0') || 0
  const workspaceId = String(session.metadata?.workspaceId || '')
  const userId = String(session.metadata?.userId || '')

  if (!qty || !workspaceId) return

  const existing = await prisma.taskUnitLedger.findFirst({
    where: { refId: session.id, reason: 'TOP_UP' }
  })
  if (existing) return

  await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
    await tx.taskUnitLedger.create({
      data: {
        workspaceId,
        deltaTU: qty,
        reason: 'TOP_UP',
        refId: session.id
      }
    })
    await tx.workspace.update({
      where: { id: workspaceId },
      data: { tuBalance: { increment: qty } }
    })
    const auditData: any = {
      action: 'TU_TOPUP_CREDITED',
      details: { source: 'stripe', qty, checkoutSessionId: session.id },
      workspaceId
    }
    if (userId) auditData.userId = userId
    await tx.auditLog.create({ data: auditData })
  })
}
async function handleInvoicePaid(invoice: Stripe.Invoice) {
  try {
    const customerId = invoice.customer as string
    if (!customerId) return

    const user = await prisma.user.findFirst({
      where: {
        subscription: {
          stripeCustomerId: customerId
        }
      }
    })
    if (!user?.id) return

    const membership = await prisma.workspaceMember.findFirst({
      where: { userId: user.id },
      include: { workspace: true }
    })
    const workspaceId = membership?.workspace?.id
    if (!workspaceId) return

    if (!Array.isArray(invoice.lines?.data) || invoice.lines.data.length === 0) return

    for (const line of invoice.lines.data) {
      const price = line.price
      const amount = (line.amount ?? 0) / 100
      const qty = line.quantity ?? 1

      if (!price) continue

      let isTaskUnit = false
      if (price.metadata && (price.metadata.item_type === 'TU' || price.metadata.type === 'tu_topup')) {
        isTaskUnit = true
      }
      if (!isTaskUnit && price.product && typeof price.product === 'string') {
        try {
          const product = await stripe.products.retrieve(price.product)
          if (product?.metadata && (product.metadata.item_type === 'TU' || product.metadata.type === 'tu_topup')) {
            isTaskUnit = true
          }
        } catch {}
      }
      if (isTaskUnit) continue

      const itemType =
        price.metadata?.item_type ||
        (price.recurring ? (price.nickname?.toUpperCase().includes('WORKSPACE') ? 'WORKSPACE_ADDON' :
                            price.nickname?.toUpperCase().includes('USER') ? 'USER_ADDON' : 'BASE_PLAN') : 'BASE_PLAN')

      const commissionAmount = Number((amount * 0.5).toFixed(2))
      const attribution = await prisma.affiliateAttribution.findFirst({
        where: { referredUserId: user.id, active: true },
        include: { affiliate: true }
      })
      if (!attribution?.affiliate?.id) {
        continue
      }

      const cycleAt = invoice.status_transitions?.paid_at
        ? new Date(invoice.status_transitions.paid_at * 1000)
        : new Date(invoice.created * 1000)

      const duplicate = await prisma.affiliateCommission.findFirst({
        where: {
          affiliateId: attribution.affiliate.id,
          workspaceId,
          customerUserId: user.id,
          itemType,
          amountUSD: commissionAmount,
          cycleAt
        }
      })
      if (duplicate) continue

      await prisma.affiliateCommission.create({
        data: {
          affiliateId: attribution.affiliate.id,
          workspaceId,
          customerUserId: user.id,
          itemType,
          amountUSD: commissionAmount,
          percentage: 50,
          cycleAt,
          stripeTransferId: null,
          status: 'pending'
        }
      })
    }
  } catch (e) {
    console.error('handleInvoicePaid error', e)
  }
}
