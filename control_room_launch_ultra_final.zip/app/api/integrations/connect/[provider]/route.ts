import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { encrypt } from '@/lib/crypto'

function makeRedirectUri(baseUrl: string, provider: string) {
  return `${baseUrl}/api/integrations/connect/${provider.toLowerCase()}`
}

export async function GET(
  req: NextRequest,
  { params }: { params: { provider: string } }
) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.redirect(new URL('/login', req.url))

  const provider = (params.provider || '').toUpperCase()
  const baseUrl = process.env.NEXTAUTH_URL || new URL(req.url).origin
  const url = new URL(req.url)
  const code = url.searchParams.get('code')
  const state = url.searchParams.get('state')
  const workspaceId = session.user.workspaceId
  if (!workspaceId) return NextResponse.json({ error: 'No active workspace' }, { status: 400 })

  try {
    if (!code) {
      switch (provider) {
        case 'GOOGLE': {
          const clientId = process.env.GOOGLE_CLIENT_ID!
          const redirectUri = makeRedirectUri(baseUrl, 'google')
          const scope = encodeURIComponent([
            'https://www.googleapis.com/auth/userinfo.email',
            'https://www.googleapis.com/auth/gmail.send',
            'https://www.googleapis.com/auth/calendar.events'
          ].join(' '))
          const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=${encodeURIComponent(clientId)}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}&access_type=offline&prompt=consent&state=cr_${workspaceId}`
          return NextResponse.redirect(authUrl)
        }
        case 'SLACK': {
          const clientId = process.env.SLACK_CLIENT_ID!
          const redirectUri = makeRedirectUri(baseUrl, 'slack')
          const scope = encodeURIComponent(['chat:write','channels:read','users:read','groups:read'].join(','))
          const authUrl = `https://slack.com/oauth/v2/authorize?client_id=${encodeURIComponent(clientId)}&scope=${scope}&redirect_uri=${encodeURIComponent(redirectUri)}&state=cr_${workspaceId}`
          return NextResponse.redirect(authUrl)
        }
        case 'GITHUB': {
          const clientId = process.env.GITHUB_CLIENT_ID!
          const redirectUri = makeRedirectUri(baseUrl, 'github')
          const scope = encodeURIComponent('repo,issues')
          const authUrl = `https://github.com/login/oauth/authorize?client_id=${encodeURIComponent(clientId)}&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}&state=cr_${workspaceId}`
          return NextResponse.redirect(authUrl)
        }
        default:
          return NextResponse.json({ error: 'Unknown provider' }, { status: 400 })
      }
    }

    switch (provider) {
      case 'GOOGLE': {
        const clientId = process.env.GOOGLE_CLIENT_ID!
        const clientSecret = process.env.GOOGLE_CLIENT_SECRET!
        const redirectUri = makeRedirectUri(baseUrl, 'google')
        const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            code: code!,
            client_id: clientId,
            client_secret: clientSecret,
            redirect_uri: redirectUri,
            grant_type: 'authorization_code'
          })
        })
        if (!tokenRes.ok) return NextResponse.json({ error: 'Google token exchange failed' }, { status: 400 })
        const tokenJson = await tokenRes.json()
        const accessToken = tokenJson.access_token as string
        const refreshToken = tokenJson.refresh_token as string | undefined
        const expiresIn = tokenJson.expires_in as number | undefined
        const scopesArr = (tokenJson.scope as string | undefined)?.split(' ') || []
        const scopes = scopesArr.join(' ')

        await prisma.integrationConnection.upsert({
          where: { workspaceId_provider: { workspaceId, provider: 'GOOGLE' } },
          create: {
            workspaceId,
            provider: 'GOOGLE',
            status: 'CONNECTED',
            scopes,
            tokenEnc: encrypt(accessToken),
            refreshTokenEnc: refreshToken ? encrypt(refreshToken) : null,
            expiresAt: expiresIn ? new Date(Date.now() + expiresIn * 1000) : null
          },
          update: {
            status: 'CONNECTED',
            scopes,
            tokenEnc: encrypt(accessToken),
            refreshTokenEnc: refreshToken ? encrypt(refreshToken) : null,
            expiresAt: expiresIn ? new Date(Date.now() + expiresIn * 1000) : null,
            updatedAt: new Date()
          }
        })
        return NextResponse.redirect(new URL('/dashboard/integrations?connected=google', baseUrl))
      }
      case 'SLACK': {
        const clientId = process.env.SLACK_CLIENT_ID!
        const clientSecret = process.env.SLACK_CLIENT_SECRET!
        const redirectUri = makeRedirectUri(baseUrl, 'slack')
        const tokenRes = await fetch('https://slack.com/api/oauth.v2.access', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            code: code!,
            client_id: clientId,
            client_secret: clientSecret,
            redirect_uri: redirectUri
          })
        })
        const tokenJson = await tokenRes.json()
        if (!tokenJson.ok) return NextResponse.json({ error: 'Slack token exchange failed' }, { status: 400 })
        const accessToken = tokenJson.access_token as string
        const scopesStr = (tokenJson.authed_user?.scope as string | undefined) || ''
        const scopes = scopesStr

        await prisma.integrationConnection.upsert({
          where: { workspaceId_provider: { workspaceId, provider: 'SLACK' } },
          create: {
            workspaceId,
            provider: 'SLACK',
            status: 'CONNECTED',
            scopes,
            tokenEnc: encrypt(accessToken)
          },
          update: {
            status: 'CONNECTED',
            scopes,
            tokenEnc: encrypt(accessToken),
            updatedAt: new Date()
          }
        })
        return NextResponse.redirect(new URL('/dashboard/integrations?connected=slack', baseUrl))
      }
      case 'GITHUB': {
        const clientId = process.env.GITHUB_CLIENT_ID!
        const clientSecret = process.env.GITHUB_CLIENT_SECRET!
        const redirectUri = makeRedirectUri(baseUrl, 'github')
        const tokenRes = await fetch('https://github.com/login/oauth/access_token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify({
            code: code!,
            client_id: clientId,
            client_secret: clientSecret,
            redirect_uri: redirectUri
          })
        })
        if (!tokenRes.ok) return NextResponse.json({ error: 'GitHub token exchange failed' }, { status: 400 })
        const tokenJson = await tokenRes.json()
        const accessToken = tokenJson.access_token as string
        const scopeStr = tokenJson.scope as string | undefined
        const scopes = scopeStr || ''

        await prisma.integrationConnection.upsert({
          where: { workspaceId_provider: { workspaceId, provider: 'GITHUB' } },
          create: {
            workspaceId,
            provider: 'GITHUB',
            status: 'CONNECTED',
            scopes,
            tokenEnc: encrypt(accessToken)
          },
          update: {
            status: 'CONNECTED',
            scopes,
            tokenEnc: encrypt(accessToken),
            updatedAt: new Date()
          }
        })
        return NextResponse.redirect(new URL('/dashboard/integrations?connected=github', baseUrl))
      }
      default:
        return NextResponse.json({ error: 'Unknown provider' }, { status: 400 })
    }
  } catch (e) {
    return NextResponse.json({ error: 'OAuth failed' }, { status: 500 })
  }
}
