import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const url = new URL(req.url)
  const providerParam = (url.searchParams.get('provider') || '').toUpperCase()
  const workspaceId = session.user.workspaceId
  if (!providerParam || !workspaceId) return NextResponse.json({ error: 'Missing provider or workspace' }, { status: 400 })

  await prisma.integrationConnection.deleteMany({
    where: { workspaceId, provider: providerParam as any }
  })

  return NextResponse.json({ ok: true })
}
