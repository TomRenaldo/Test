import { NextResponse } from 'next/server'
export async function GET() {
  // Replace with your Notion OAuth URL & client details
  const redirect = `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/integrations/notion/callback`
  const url = `https://api.notion.com/v1/oauth/authorize?owner=user&client_id=${process.env.NOTION_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirect)}&response_type=code`
  return NextResponse.redirect(url)
}
