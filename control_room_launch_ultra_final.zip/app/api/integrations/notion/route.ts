import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function DELETE() {
  const workspaceId = 'demo-workspace'
  await prisma.integrationToken.deleteMany({ where: { workspaceId, provider: 'notion' } })
  return NextResponse.json({ ok: true })
}
