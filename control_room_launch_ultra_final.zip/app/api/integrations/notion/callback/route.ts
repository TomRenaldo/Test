import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { encrypt } from '@/lib/crypto'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const code = searchParams.get('code')
  if (!code) return NextResponse.redirect('/dashboard/integrations?error=notion_no_code')
  // Exchange code for token (placeholder; implement real token call)
  const access_token = `notion_${code}`
  const workspaceId = 'demo-workspace'
  await prisma.integrationToken.upsert({
    where: { provider_workspaceId: { provider: 'notion', workspaceId } },
    update: { token: encrypt(access_token), updatedAt: new Date() },
    create: { provider: 'notion', workspaceId, token: encrypt(access_token) }
  })
  return NextResponse.redirect('/dashboard/integrations?connected=notion')
}
