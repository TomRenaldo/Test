import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import Stripe from 'stripe'
import { prisma } from '@/lib/prisma'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16'
})

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || !session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { quantity = 0, workspaceId } = await request.json()
    const tuPriceId = process.env.STRIPE_TU_TOPUP_PRICE_ID
    if (!tuPriceId) {
      return NextResponse.json({ error: 'Missing STRIPE_TU_TOPUP_PRICE_ID' }, { status: 500 })
    }
    const qty = Math.max(1, Number(quantity) || 0)

    let effectiveWorkspaceId = workspaceId || (session.user as any).workspaceId
    if (!effectiveWorkspaceId) {
      const membership = await prisma.workspaceMember.findFirst({
        where: { userId: session.user.id },
        orderBy: { joinedAt: 'asc' }
      })
      effectiveWorkspaceId = membership?.workspaceId
    }
    if (!effectiveWorkspaceId) {
      return NextResponse.json({ error: 'Workspace ID required' }, { status: 400 })
    }

    const checkout = await stripe.checkout.sessions.create({
      customer_email: session.user.email,
      line_items: [{ price: tuPriceId, quantity: qty }],
      mode: 'payment',
      success_url: `${process.env.NEXTAUTH_URL}/dashboard/settings?topup=success&cs={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXTAUTH_URL}/dashboard/settings?topup=cancelled`,
      metadata: {
        type: 'tu_topup',
        userId: session.user.id,
        workspaceId: effectiveWorkspaceId,
        quantity: String(qty)
      }
    })

    return NextResponse.json({ url: checkout.url })
  } catch (e) {
    return NextResponse.json({ error: 'Failed to create TU top-up session' }, { status: 500 })
  }
}
