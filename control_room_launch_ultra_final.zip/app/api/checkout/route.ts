import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16'
})

const PRICES = {
  BASE_PLAN_PRICE_ID: process.env.STRIPE_BASE_PLAN_PRICE_ID || '',
  ADDON_WORKSPACE_PRICE_ID: process.env.STRIPE_ADDON_WORKSPACE_PRICE_ID || '',
  ADDON_USER_PRICE_ID: process.env.STRIPE_ADDON_USER_PRICE_ID || '',
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || !session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { workspaces = 1, users = 1, trial = false } = await request.json()

    if (!PRICES.BASE_PLAN_PRICE_ID || !PRICES.ADDON_WORKSPACE_PRICE_ID || !PRICES.ADDON_USER_PRICE_ID) {
      return NextResponse.json({ error: 'Missing Stripe price IDs' }, { status: 500 })
    }

    const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] = [
      { price: PRICES.BASE_PLAN_PRICE_ID, quantity: 1 },
    ]

    const extraWorkspaces = Math.max(0, Number(workspaces) - 1)
    const extraUsers = Math.max(0, Number(users) - 1)

    if (extraWorkspaces > 0) {
      line_items.push({ price: PRICES.ADDON_WORKSPACE_PRICE_ID, quantity: extraWorkspaces })
    }
    if (extraUsers > 0) {
      line_items.push({ price: PRICES.ADDON_USER_PRICE_ID, quantity: extraUsers })
    }

    const checkoutSession = await stripe.checkout.sessions.create({
      customer_email: session.user.email,
      line_items,
      mode: 'subscription',
      success_url: `${process.env.NEXTAUTH_URL}/dashboard?checkout=success`,
      cancel_url: `${process.env.NEXTAUTH_URL}/pricing?checkout=cancelled`,
      metadata: {
        userId: session.user.id,
        workspaces: String(workspaces),
        users: String(users),
        type: 'subscription'
      },
      subscription_data: trial ? { trial_period_days: 7 } : undefined,
    })

    return NextResponse.json({ url: checkoutSession.url })
  } catch (error) {
    console.error('Checkout session creation error:', error)
    return NextResponse.json({ error: 'Failed to create checkout session' }, { status: 500 })
  }
}
