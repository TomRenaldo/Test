import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { prisma } from '@/lib/prisma'
import type { Prisma } from '@prisma/client'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2023-10-16' })

export async function POST(request: NextRequest) {
  try {
    const { sessionId } = await request.json()
    if (!sessionId) return NextResponse.json({ error: 'Missing sessionId' }, { status: 400 })

    const session = await stripe.checkout.sessions.retrieve(sessionId)
    if (!session || session.mode !== 'payment') {
      return NextResponse.json({ error: 'Invalid session' }, { status: 400 })
    }
    if (session.payment_status !== 'paid') {
      return NextResponse.json({ error: 'Session not paid' }, { status: 409 })
    }
    const md = session.metadata || {}
    if (md.type !== 'tu_topup') {
      return NextResponse.json({ error: 'Not a TU top-up session' }, { status: 400 })
    }
    const qty = Number(md.quantity || '0') || 0
    const workspaceId = md.workspaceId || ''
    const userId = md.userId || ''
    if (!qty || !workspaceId) {
      return NextResponse.json({ error: 'Missing workspace or quantity' }, { status: 400 })
    }

    const already = await prisma.taskUnitLedger.findFirst({
      where: { refId: session.id, reason: 'TOP_UP' }
    })
    if (already) {
      return NextResponse.json({ credited: true, balanceUpdated: false })
    }

    await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      await tx.taskUnitLedger.create({
        data: {
          workspaceId,
          deltaTU: qty,
          reason: 'TOP_UP',
          refId: session.id
        }
      })
      await tx.workspace.update({
        where: { id: workspaceId },
        data: { tuBalance: { increment: qty } }
      })
      await tx.auditLog.create({
        data: {
          userId: userId,
          action: 'TU_TOPUP_CREDITED_VIA_CONFIRM',
          details: ({ source: 'stripe-confirm', qty, checkoutSessionId: session.id } as unknown as Prisma.InputJsonValue),
          workspaceId
        }
      })
    })

    return NextResponse.json({ credited: true })
  } catch (e) {
    return NextResponse.json({ error: 'Failed to confirm top-up' }, { status: 500 })
  }
}
