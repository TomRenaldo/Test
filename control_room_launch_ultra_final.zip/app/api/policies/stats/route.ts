import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(request.url)
  const workspaceId = searchParams.get('workspaceId') || (session.user as any).workspaceId
  if (!workspaceId) return NextResponse.json({ error: 'Workspace ID required' }, { status: 400 })

  const [active, paused, enforced, errors] = await Promise.all([
    prisma.policy.count({ where: { workspaceId, isActive: true } }),
    prisma.policy.count({ where: { workspaceId, isActive: false } }),
    prisma.policy.count({ where: { workspaceId, isEnforced: true } as any }),
    prisma.policy.count({ where: { workspaceId, errorCount: { gt: 0 } } }),
  ])

  return NextResponse.json({ active, enforced, errors, paused })
}
