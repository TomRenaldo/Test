import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { getTUBalance } from '@/lib/tu'

export async function GET(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(request.url)
  const workspaceId = searchParams.get('workspaceId') || (session.user as any).workspaceId
  if (!workspaceId) return NextResponse.json({ error: 'Workspace ID required' }, { status: 400 })

  const balance = await getTUBalance(workspaceId)
  return NextResponse.json({ balance })
}
