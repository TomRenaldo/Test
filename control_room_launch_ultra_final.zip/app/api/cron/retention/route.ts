import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function POST() {
  const cutoff = new Date(Date.now() - 90*24*60*60*1000)
  const logs = await prisma.auditLog.deleteMany({ where: { createdAt: { lt: cutoff } } })
  // If task logs are a separate table/field, prune similarly (placeholder)
  return NextResponse.json({ ok: true, prunedAudit: logs.count })
}
