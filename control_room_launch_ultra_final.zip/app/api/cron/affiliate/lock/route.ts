
import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function POST() {
  const cutoff = new Date(Date.now() - 30*24*60*60*1000)
  const res = await prisma.affiliateCommission.updateMany({
    where: { status: 'pending', createdAt: { lte: cutoff } },
    data: { status: 'locked' }
  })
  return NextResponse.json({ ok: true, locked: res.count })
}
