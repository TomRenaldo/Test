import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function POST() {
  const start = new Date(); start.setHours(0,0,0,0)
  const end = new Date(); end.setHours(23,59,59,999)
  const policies = await prisma.policy.findMany({ where: { active: true } })
  let triggered = 0
  for (const p of policies) {
    if (p.trigger.includes('failure_rate_today')) {
      const tasks = await prisma.task.findMany({ where: { createdAt: { gte: start, lte: end } }, select: { status:true } })
      const total = tasks.length || 1
      const failures = tasks.filter(t=>t.status==='FAILED').length
      const rate = failures / total
      const threshold = parseFloat(p.trigger.split('>').pop() || '1')
      if (rate > threshold) { triggered++ }
    }
  }
  return NextResponse.json({ ok: true, triggered })
}
