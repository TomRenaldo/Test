import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

function sinceMinutes(m:number) {
  const d = new Date()
  d.setMinutes(d.getMinutes()-m)
  return d
}

export async function POST() {
  const ws = 'demo-workspace'
  const policies = await prisma.policy.findMany({ where: { workspaceId: ws, active: true } })
  let triggered = 0
  for (const p of policies) {
    const trig = (p.trigger || '').toLowerCase()
    if (trig.includes('failure_rate')) {
      const m = parseInt(trig.match(/over\s*(\d+)m/)?.[1] || '60')
      const th = parseFloat(trig.match(/>([0-9.]+)/)?.[1] || '0.2')
      const tasks = await prisma.task.findMany({ where: { createdAt: { gte: sinceMinutes(m) } }, select: { status:true } })
      const total = tasks.length || 1
      const failures = tasks.filter(t=>t.status==='FAILED').length
      const rate = failures/total
      if (rate > th) {
        triggered++
        await prisma.auditLog.create({ data: { id: crypto.randomUUID(), workspaceId: ws, kind: 'policy.trigger', message: `failure_rate ${rate.toFixed(2)} > ${th}` } as any })
      }
    }
    if (trig.includes('tu_balance')) {
      const th = parseFloat(trig.match(/<\s*([0-9.]+)/)?.[1] || '5')
      const acct = await prisma.billingAccount.findUnique({ where: { workspaceId: ws } })
      const bal = Number(acct?.tuBalance || 0)
      if (bal < th) {
        triggered++
        await prisma.auditLog.create({ data: { id: crypto.randomUUID(), workspaceId: ws, kind: 'policy.trigger', message: `tu_balance ${bal} < ${th}` } as any })
      }
    }
  }
  return NextResponse.json({ ok: true, triggered })
}
