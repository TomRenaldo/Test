import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(request.url)
  const workspaceId =
    searchParams.get('workspaceId') ||
    (session.user as any).activeWorkspaceId ||
    (session.user as any).workspaceId
  if (!workspaceId) return NextResponse.json({ error: 'Workspace ID required' }, { status: 400 })

  const [active, completed, failed, paused] = await Promise.all([
    prisma.task.count({ where: { workspaceId, status: { in: ['RUNNING', 'SCHEDULED', 'PENDING'] } } }),
    prisma.task.count({ where: { workspaceId, status: 'COMPLETED' } }),
    prisma.task.count({ where: { workspaceId, status: 'FAILED' } }),
    prisma.task.count({ where: { workspaceId, status: 'PAUSED' } }),
  ])

  return NextResponse.json({ active, completed, errors: failed, paused })
}
