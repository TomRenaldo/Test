import { NextResponse } from 'next/server'
import { estimateRawCostUSD, toTaskUnits } from '@/lib/billing/estimator'

async function planWithOpenAI(description: string) {
  try {
    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) return null
    const payload = {
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      response_format: { type: 'json_object' },
      messages: [
        { role: 'system', content: 'Output strictly JSON: { "steps": string[], "parameters": object }' },
        { role: 'user', content: `Describe a minimal capability plan for: ${description}. Capabilities: slack.postMessage, github.createIssue, email.send, http.request` }
      ]
    }
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    if (!res.ok) return null
    const data = await res.json()
    const text = data?.choices?.[0]?.message?.content || '{}'
    const json = JSON.parse(text)
    return { steps: Array.isArray(json.steps) ? json.steps : [], usage: data?.usage || null, model: data?.model || (process.env.OPENAI_MODEL || 'gpt-4o-mini') }
  } catch { return null }
}

const tok = (s:string)=> Math.ceil((s||'').length/4)

export async function POST(req: Request) {
  const { description = '' } = await req.json()
  const ai = await planWithOpenAI(description)
  let steps: string[] = ai?.steps?.length ? ai.steps : []
  if (!steps.length) {
    const d = (description || '').toLowerCase()
    if (d.includes('slack')) steps.push('slack.postMessage')
    if (d.includes('github')) steps.push('github.createIssue')
    if (d.includes('email')) steps.push('email.send')
    if (!steps.length) steps.push('http.request')
  }
  const model = ai?.model || (process.env.OPENAI_MODEL || 'gpt-4o-mini')
  const promptTokens = ai?.usage?.prompt_tokens ?? tok(description)
  const completionTokens = ai?.usage?.completion_tokens ?? 128
  const rawUSD = estimateRawCostUSD({ model, promptTokens, completionTokens, storageKB: 8, integrations: steps.map(s=>({provider:s, units:1, unitUSD:0.002})) })
  const estimateTU = toTaskUnits(rawUSD)
  return NextResponse.json({ plan: { steps, estimateTU, model, promptTokens, completionTokens } })
}
