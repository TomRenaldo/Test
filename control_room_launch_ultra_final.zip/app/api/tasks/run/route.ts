import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { estimateRawCostUSD, toTaskUnits } from '@/lib/billing/estimator'

const tok = (s:string)=> Math.ceil((s||'').length/4)

export async function POST(req: Request) {
  const { description = '', confirm = false, model = (process.env.OPENAI_MODEL || 'gpt-4o-mini') } = await req.json()
  if (!confirm) return NextResponse.json({ ok:false, error:'not confirmed' }, { status: 400 })

  const rawUSD = estimateRawCostUSD({ model, promptTokens: tok(description), completionTokens: 128, storageKB: 8, integrations: [] })
  const tuCost = toTaskUnits(rawUSD)

  const workspaceId = 'demo-workspace'
  let acct = await prisma.billingAccount.findUnique({ where: { workspaceId } })
  if (!acct) acct = await prisma.billingAccount.create({ data: { workspaceId, tuBalance: 10 } })
  if (Number(acct.tuBalance) < tuCost) return NextResponse.json({ ok:false, error:'insufficient_tu', need: tuCost, have: Number(acct.tuBalance) }, { status: 402 })
  await prisma.billingAccount.update({ where: { workspaceId }, data: { tuBalance: { decrement: tuCost } } })
  try { await prisma.task.create({ data: { description, status: 'QUEUED', estimatedTU: tuCost, actualTU: tuCost } as any }) } catch {}
  return NextResponse.json({ ok:true, chargedTU: tuCost })
}
