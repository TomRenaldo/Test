import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { requireSufficientTU } from '@/lib/tu'
import { planTask } from '@/lib/ai/master'

export async function GET(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(request.url)
  const workspaceId = searchParams.get('workspaceId') || (session.user as any).workspaceId
  if (!workspaceId) return NextResponse.json({ error: 'Workspace ID required' }, { status: 400 })

  const tasks = await prisma.task.findMany({
    where: { workspaceId },
    orderBy: { createdAt: 'desc' }
  })
  return NextResponse.json({ tasks })
}

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await request.json()
  const { workspaceId: wsFromBody, input, confirm, schedule } = body || {}
  const workspaceId = wsFromBody || (session.user as any).workspaceId
  if (!workspaceId) return NextResponse.json({ error: 'Workspace ID required' }, { status: 400 })
  if (!input?.trim()) return NextResponse.json({ error: 'Input required' }, { status: 400 })

  const preflight = await planTask(input)
  const plan = { steps: preflight.steps, notes: preflight.notes }
  const estimatedTU = preflight.estimatedTU

  if (!confirm) {
    return NextResponse.json({ plan, estimatedTU })
  }

  try {
    await requireSufficientTU(workspaceId, estimatedTU)
  } catch (e: any) {
    if (e?.message === 'INSUFFICIENT_TU') {
      return NextResponse.json({ error: 'INSUFFICIENT_TU' }, { status: 402 })
    }
    return NextResponse.json({ error: 'Failed to validate Task Units' }, { status: 500 })
  }

  const task = await prisma.task.create({
    data: {
      workspaceId,
      userId: session.user.id,
      title: input.slice(0, 120),
      description: input,
      status: 'PENDING',
      schedule: schedule || null,
      estimatedCostTU: estimatedTU
    }
  })

  return NextResponse.json({ taskId: task.id, status: 'PENDING', estimatedTU })
}

export async function PATCH(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await request.json()
  const { id, action, schedule } = body || {}
  if (!id) return NextResponse.json({ error: 'Task ID required' }, { status: 400 })

  const task = await prisma.task.findUnique({ where: { id } })
  if (!task) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  if (action === 'pause') {
    await prisma.task.update({ where: { id }, data: { paused: true, status: 'PAUSED' as any } })
  } else if (action === 'resume') {
    await prisma.task.update({ where: { id }, data: { paused: false, status: 'PENDING' as any } })
  } else if (action === 'schedule') {
    await prisma.task.update({ where: { id }, data: { schedule: schedule || null } })
  } else {
    return NextResponse.json({ error: 'Unsupported action' }, { status: 400 })
  }

  return NextResponse.json({ ok: true })
}

export async function DELETE(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'Task ID required' }, { status: 400 })

  await prisma.task.delete({ where: { id } })
  await prisma.taskLog.deleteMany({ where: { taskId: id } })

  return NextResponse.json({ ok: true })
}
