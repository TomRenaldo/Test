import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const taskId = params.id
  if (!taskId) return NextResponse.json({ error: 'Task ID required' }, { status: 400 })

  const task = await prisma.task.findUnique({ where: { id: taskId }, select: { workspaceId: true, userId: true } })
  if (!task) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const logs = await prisma.taskLog.findMany({
    where: { taskId },
    orderBy: { createdAt: 'asc' },
    take: 500
  })

  return NextResponse.json({
    logs: logs.map(l => ({
      id: l.id,
      level: l.level,
      message: l.message,
      metadata: l.metadata,
      createdAt: l.createdAt
    }))
  })
}
