import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { requireSufficientTU, debitTU, estimateTaskUnits } from '@/lib/tu'
import { planTask } from '@/lib/ai/master'

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const taskId = params.id

  const task = await prisma.task.findUnique({ where: { id: taskId } })
  if (!task) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (task.paused) return NextResponse.json({ error: 'Task is paused' }, { status: 400 })

  const estimated = Number(task.estimatedCostTU ?? estimateTaskUnits({ openaiUSD: 0.01, storageUSD: 0.001, integrationsUSD: 0 }))
  try {
    await requireSufficientTU(task.workspaceId, estimated)
  } catch (e: any) {
    if (e?.message === 'INSUFFICIENT_TU') {
      return NextResponse.json({ code: 'INSUFFICIENT_TU' }, { status: 402 })
    }
    throw e
  }

  await prisma.task.update({ where: { id: taskId }, data: { status: 'RUNNING' } })
  await prisma.taskLog.create({
    data: { taskId, level: 'info', message: 'Execution started' }
  })

  try {
    const plan = await planTask(task.description || task.title || '')
    for (const step of plan.steps) {
      await prisma.taskLog.create({
        data: { taskId, level: 'info', message: `Executing ${step.capability}`, metadata: { input: step.input } }
      })
      await fetch(`${process.env.NEXT_PUBLIC_APP_URL || ''}/api/capabilities/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ capabilityId: step.capability, input: step.input, taskId })
      })
    }

    await prisma.task.update({ where: { id: taskId }, data: { status: 'COMPLETED', costTU: estimated } })
    await debitTU(task.workspaceId, estimated, taskId)

    await prisma.taskLog.create({
      data: { taskId, level: 'info', message: 'Execution completed', metadata: { costTU: estimated } }
    })

    return NextResponse.json({ status: 'COMPLETED', costTU: estimated })
  } catch (e: any) {
    await prisma.task.update({ where: { id: taskId }, data: { status: 'FAILED' } })
    await prisma.taskLog.create({
      data: { taskId, level: 'error', message: 'Execution failed', metadata: { error: e?.message || String(e) } }
    })
    return NextResponse.json({ error: 'Execution failed' }, { status: 500 })
  }
}
