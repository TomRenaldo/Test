import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET() {
  const workspaceId = 'demo-workspace'
  let acct = await prisma.billingAccount.findUnique({ where: { workspaceId } })
  if (!acct) acct = await prisma.billingAccount.create({ data: { workspaceId, tuBalance: 10 } })
  return NextResponse.json({ tu: Number(acct.tuBalance) })
}
export async function POST(req: Request) {
  const { delta = 0 } = await req.json()
  const workspaceId = 'demo-workspace'
  const acct = await prisma.billingAccount.upsert({
    where: { workspaceId },
    update: { tuBalance: { increment: Number(delta) } },
    create: { workspaceId, tuBalance: Number(delta) }
  })
  return NextResponse.json({ tu: Number(acct.tuBalance) })
}
