import { NextResponse } from 'next/server'
export async function POST(req: Request) {
  const { quantity = 10 } = await req.json()
  return NextResponse.json({ checkoutUrl: `/stub-checkout?qty=${quantity}` })
}
