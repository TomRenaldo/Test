import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { getCapability } from '@/lib/integrations/catalog'
import { decrypt } from '@/lib/crypto'

export async function POST(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await request.json()
  const { capabilityId, input, taskId } = body || {}
  if (!capabilityId || !taskId) return NextResponse.json({ error: 'capabilityId and taskId required' }, { status: 400 })

  const cap = getCapability(capabilityId)
  if (!cap) return NextResponse.json({ error: 'Unknown capability' }, { status: 400 })

  const task = await prisma.task.findUnique({ where: { id: taskId } })
  if (!task) return NextResponse.json({ error: 'Task not found' }, { status: 404 })

  await prisma.taskLog.create({
    data: { taskId, level: 'info', message: `Validated capability ${cap.key}`, metadata: { input } }
  })

  let result: any = null

  try {
    if (cap.key === 'slack.postMessage') {
      const conn = await prisma.integrationConnection.findFirst({
        where: { workspaceId: task.workspaceId, provider: 'SLACK', status: 'CONNECTED' }
      })
      if (!conn?.tokenEnc) {
        throw new Error('SLACK_NOT_CONNECTED')
      }
      const token = decrypt(conn.tokenEnc)
      const resp = await fetch('https://slack.com/api/chat.postMessage', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ channel: input?.channel, text: input?.text })
      })
      const json = await resp.json()
      if (!json.ok) {
        throw new Error(`SLACK_API_ERROR:${json?.error || 'unknown'}`)
      }
      result = { ts: json.ts, channel: json.channel }
      await prisma.integrationConnection.updateMany({
        where: { workspaceId: task.workspaceId, provider: 'SLACK' },
        data: { lastUsedAt: new Date() }
      })
    } else if (cap.key === 'gmail.send') {
      await prisma.taskLog.create({
        data: { taskId, level: 'info', message: 'gmail.send execution stub', metadata: { to: input?.to } }
      })
      result = { ok: true }
    } else if (cap.key === 'calendar.createEvent') {
      await prisma.taskLog.create({
        data: { taskId, level: 'info', message: 'calendar.createEvent execution stub', metadata: { title: input?.title } }
      })
      result = { ok: true }
    } else if (cap.key === 'github.createIssue') {
      const conn = await prisma.integrationConnection.findFirst({
        where: { workspaceId: task.workspaceId, provider: 'GITHUB', status: 'CONNECTED' }
      })
      if (!conn?.tokenEnc) {
        throw new Error('GITHUB_NOT_CONNECTED')
      }
      const token = decrypt(conn.tokenEnc)
      const owner = input?.owner
      const repo = input?.repo
      const title = input?.title
      const body = input?.body
      const labels = Array.isArray(input?.labels) ? input.labels : undefined

      if (!owner || !repo || !title) {
        throw new Error('INVALID_INPUT')
      }

      const ghResp = await fetch(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/issues`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        },
        body: JSON.stringify({ title, body, labels })
      })
      if (!ghResp.ok) {
        const errTxt = await ghResp.text().catch(() => '')
        throw new Error(`GITHUB_API_ERROR:${ghResp.status}:${errTxt.slice(0,200)}`)
      }
      const ghJson = await ghResp.json()
      result = { number: ghJson.number, url: ghJson.html_url }
      await prisma.integrationConnection.updateMany({
        where: { workspaceId: task.workspaceId, provider: 'GITHUB' },
        data: { lastUsedAt: new Date() }
      })
    } else {
      await prisma.taskLog.create({
        data: { taskId, level: 'warn', message: `No executor for ${cap.key}` }
      })
      result = { skipped: true }
    }

    await prisma.taskLog.create({
      data: { taskId, level: 'info', message: `Executed ${cap.key}`, metadata: { resultHint: result } }
    })
    return NextResponse.json({ ok: true, capability: cap.key, result })
  } catch (e: any) {
    const provider = cap.key.startsWith('slack') ? 'SLACK' : cap.key.startsWith('github') ? 'GITHUB' : cap.key.startsWith('gmail') ? 'GOOGLE' : cap.key.startsWith('calendar') ? 'GOOGLE' : null
    await prisma.taskLog.create({
      data: { taskId, level: 'error', message: `Execution failed for ${cap.key}`, metadata: { error: e?.message || String(e), provider } }
    })
    if (provider) {
      await prisma.integrationConnection.updateMany({
        where: { workspaceId: task.workspaceId, provider },
        data: { lastUsedAt: new Date() }
      })
    }
    return NextResponse.json({ error: 'Capability execution failed' }, { status: 500 })
  }
}
