import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET() {
  const start = new Date(); start.setHours(0,0,0,0)
  const end = new Date(); end.setHours(23,59,59,999)
  try {
    const tasks = await prisma.task.findMany({
      where: { createdAt: { gte: start, lte: end } },
      select: { status: true, actualTU: true, createdAt: true, updatedAt: true }
    })
    const tasksToday = tasks.length
    const failuresToday = tasks.filter(t => t.status === 'FAILED').length
    const tuToday = tasks.reduce((a, t) => a + Number(t.actualTU || 0), 0)
    const latencies = tasks.filter(t => t.status === 'COMPLETED').map(t => (
      new Date(t.updatedAt as any).getTime() - new Date(t.createdAt as any).getTime()
    ))
    const percentile = (arr: number[], p: number) => {
      if (!arr.length) return 0
      const s = [...arr].sort((a,b)=>a-b)
      const i = Math.floor((p/100)*(s.length-1))
      return s[i]
    }
    return NextResponse.json({ tasksToday, failuresToday, tuToday, p50ms: percentile(latencies,50), p95ms: percentile(latencies,95) })
  } catch (e: any) {
    return NextResponse.json({ tasksToday:0, failuresToday:0, tuToday:0, p50ms:0, p95ms:0, error: e?.message || String(e) })
  }
}
