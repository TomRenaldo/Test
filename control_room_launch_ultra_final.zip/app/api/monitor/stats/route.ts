import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '../../../../lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '../../../../lib/auth'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const workspaceId = (session.user as any).workspaceId
    if (!workspaceId) {
      return NextResponse.json({
        tasks: { active: 0, completed: 0, errors: 0 },
        latency: { p50: 0, p95: 0 },
        tu: { last7d: 0, perTaskAvg: 0 },
        errorsByProvider: []
      })
    }

    const now = new Date()
    const since = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

    const [activeCount, completedCount, errorCount, tuEntries] = await Promise.all([
      prisma.task.count({
        where: { workspaceId, status: { in: ['RUNNING', 'SCHEDULED'] } as any }
      }),
      prisma.task.count({
        where: { workspaceId, status: 'COMPLETED' as any, createdAt: { gte: since } }
      }),
      prisma.task.count({
        where: { workspaceId, status: 'FAILED' as any, createdAt: { gte: since } }
      }),
      prisma.taskUnitLedger.findMany({
        where: { workspaceId, createdAt: { gte: since }, deltaTU: { lt: 0 } as any },
        select: { deltaTU: true }
      })

    ])

    const errorLogs = await prisma.taskLog.findMany({
      where: {
        task: { workspaceId },
        level: 'error' as any,
        createdAt: { gte: since }
      },
      select: { metadata: true }
    })
    const providerCounts: Record<string, number> = {}
    for (const e of errorLogs) {
      const meta: any = (e as any).metadata || {}
      const p = typeof meta.provider === 'string' ? meta.provider : undefined
      if (p) providerCounts[p] = (providerCounts[p] || 0) + 1
    }
    const errorsByProvider = Object.entries(providerCounts).map(([provider, count]) => ({ provider, count }))

    const tuConsumed = tuEntries.reduce((sum, e: any) => sum + Math.abs(Number(e.deltaTU)), 0)
    const perTaskAvg = completedCount > 0 ? tuConsumed / completedCount : 0

    return NextResponse.json({
      tasks: { active: activeCount, completed: completedCount, errors: errorCount },
      latency: { p50: 0, p95: 0 },
      tu: { last7d: Number(tuConsumed.toFixed(2)), perTaskAvg: Number(perTaskAvg.toFixed(2)) },
      errorsByProvider
    })
  } catch (e) {
    console.error('monitor stats error', e)
    return NextResponse.json({ error: 'Failed to load monitor stats' }, { status: 500 })
  }
}
