// app/api/ai-helper/explain/route.ts
import { NextResponse } from "next/server";

/** ─────────────────────────────────────────────────────────────
 *  Helper: normalize text
 *  ────────────────────────────────────────────────────────────*/
const norm = (s: string) => (s || "").toLowerCase().trim();

/** Canonical, succinct plan compare */
const PLANS_SNIPPET =
  "Starter: core agents, Policies, basic metrics. Pro: higher limits, custom metrics, alerts, RBAC, marketplace publishing. Enterprise: SSO/SAML, advanced governance, SLAs, and custom limits.";

/** Basic content tidy (removes headings/lists/fences/emojis-ish) */
function tidy(s: string): string {
  return (s || "")
    .replace(/(^|\n)\s*#{1,6}\s.*(?=\n|$)/g, "")
    .replace(/(^|\n)\s*---+\s*(?=\n|$)/g, "")
    .replace(/```[\s\S]*?```/g, "")
    .replace(/(^|\n)\s*[-*•]\s+/g, "\n")
    .replace(/[\u2000-\u206F\u2190-\u21FF\u2600-\u27FF]/g, "") // misc symbols
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Lightweight, order-insensitive intent classifier */
function classify(q: string) {
  const t = norm(q);

  // guardrails / refusals
  if (/delete .*data|erase .*data|remove .*account|gdpr|ccpa/i.test(t)) return "delete-data";
  if (/show (me )?everything|dump|all docs?|full documentation/i.test(t)) return "dump-all";

  // pricing / plans
  if (/compare .*plans?|starter|pro|enterprise|pricing/i.test(t)) return "plans";

  // marketplace
  if (/market ?place|install agents?|list(ing)? an agent/i.test(t)) return "marketplace";

  // contact/support
  if (/contact|support|reach (you|support)/i.test(t)) return "contact";

  // affiliate
  if (/affiliate|referral|commission|payout/i.test(t)) {
    if (/\$?\s*([0-9]+(\.[0-9]{1,2})?)\s*(\/)?\s*(mo|month)?/i.test(t)) return "affiliate-example";
    return "affiliate-rate";
  }

  // small talk buckets (let the client handle most, but be safe server-side)
  if (/favorite|favourite|color|colour|shape|time of day/i.test(t)) return "smalltalk";

  return "generic";
}

/** Answer writers */
function writeAnswer(intent: string, q: string): string {
  switch (intent) {
    case "plans":
      return PLANS_SNIPPET;

    case "marketplace":
      return "The Marketplace lets you discover, install, and sell vetted AI agents. Install in one click, review requested permissions, and manage updates in one place. Creators can submit agents for review before listing.";

    case "contact":
      return "You can reach the team on the Contact page. Tell me what you’re trying to do and I can also guide you step-by-step here.";

    case "affiliate-rate":
      return "Affiliates earn 50% lifetime commission based on the original plan the referral signs up for, paid while the account stays active.";

    case "affiliate-example": {
      // Extract a dollar amount if present and compute 50%
      const m = q.match(/\$?\s*([0-9]+(?:\.[0-9]{1,2})?)/);
      const amt = m ? parseFloat(m[1]) : 39;
      const cut = Math.round(amt * 0.5 * 100) / 100;
      return `At ${amt.toFixed(2)}/mo, the affiliate earns $${cut.toFixed(2)}/mo for as long as the account stays active.`;
    }

    case "delete-data":
      return "I can’t delete data via chat. To request data deletion or manage data rights, please review our Privacy Policy and reach out on the Contact page with your request details.";

    case "dump-all":
      return "I can’t dump everything at once, but I can explain any area in detail. Try a focused ask like “How do Policies work?” or “What’s in the Pro plan?”";

    case "smalltalk":
      return "I’m here to help with Control Room — want to compare plans, learn Policies, or explore the Marketplace?";

    case "generic":
    default:
      return "Tell me what you’re trying to get done (e.g., compare plans or create a policy) and I’ll point you to the right place.";
  }
}

/** Public endpoint (no auth). Short, safe, specific answers only. */
export async function POST(req: Request) {
  try {
    const { prompt } = await req.json();
    const text = typeof prompt === "string" ? prompt : "";
    const intent = classify(text);
    const raw = writeAnswer(intent, text);
    return NextResponse.json({ answer: tidy(raw) });
  } catch (err) {
    return NextResponse.json({
      answer: "Something went wrong on my side, but I’m here to help. Try rephrasing, and I’ll give you a concise answer.",
    });
  }
}