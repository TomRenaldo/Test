import { NextResponse } from 'next/server'
import Stripe from 'stripe'

export async function POST(req: Request) {
  const { quantity = 10, workspaceId = 'demo-workspace' } = await req.json()
  const secret = process.env.STRIPE_SECRET_KEY
  const price = process.env.STRIPE_TU_PRICE_ID
  if (!secret || !price) return NextResponse.json({ error: 'stripe_not_configured' }, { status: 500 })
  const stripe = new Stripe(secret, { apiVersion: '2024-06-20' })
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [{ price, quantity }],
    metadata: { workspaceId, tuQty: String(quantity) },
    success_url: `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/dashboard/settings?topup=success`,
    cancel_url: `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/dashboard/settings?topup=cancel`,
  })
  return NextResponse.json({ checkoutUrl: session.url })
}
