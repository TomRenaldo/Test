'use client'

export const dynamic = 'force-dynamic'

import React, { useState, useCallback } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Chrome, Mail, Lock } from 'lucide-react'

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [showPw, setShowPw] = useState(false)
  const router = useRouter()

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')
    try {
      const res = await signIn('credentials', { email, password, redirect: false })
      if (res?.error) setError('Invalid credentials')
      else router.push('/dashboard')
    } catch {
      setError('An error occurred. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleGoogleLogin = async () => {
    setIsLoading(true)
    try {
      await signIn('google', { callbackUrl: '/dashboard' })
    } catch {
      setError('Google sign-in failed')
      setIsLoading(false)
    }
  }

  return (
    <>
      <GlobalStyles />

      {/* Background */}
      <div className="min-h-screen relative overflow-hidden">
        {/* soft aurora */}
        <div
          aria-hidden
          className="pointer-events-none absolute -top-40 right-[-10%] h-[520px] w-[820px] rounded-full opacity-30 blur-3xl"
          style={{ background: 'radial-gradient(60% 60% at 50% 50%, #6E74FF 0%, rgba(110,116,255,0) 70%)' }}
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-48 left-[-10%] h-[520px] w-[820px] rounded-full opacity-25 blur-3xl"
          style={{ background: 'radial-gradient(60% 60% at 50% 50%, #8A7FFF 0%, rgba(138,127,255,0) 70%)' }}
        />

        {/* Centered card */}
        <div className="relative z-10 mx-auto flex max-w-md flex-col items-center px-6 py-14">
          {/* Brand */}
          <Link href="/" className="mb-10 inline-flex select-none items-center gap-2">
            <span className="text-[12px] font-semibold uppercase tracking-[0.38em] text-white/90">
              CONTROL&nbsp;ROOM
            </span>
            <span className="rounded-full border border-indigo-200/30 bg-indigo-200/10 px-2 py-[2px] text-[10px] uppercase tracking-[.14em] text-indigo-100">
              Beta
            </span>
          </Link>

          {/* Glass card */}
          <div
            className="relative w-full overflow-hidden rounded-2xl border border-white/10 bg-[#0B111B]/80 backdrop-blur-xl shadow-[0_24px_90px_rgba(0,0,0,.55)]"
          >
            {/* top highlight */}
            <div
              aria-hidden
              className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-white/10 to-transparent"
            />
            {/* inner */}
            <div className="relative p-7 md:p-8">
              <div className="mb-7 text-center">
                <h1 className="text-3xl font-bold tracking-tight text-white">Access Command Center</h1>
                <p className="mt-2 text-sm text-slate-300">Sign in to monitor and control your AI agents</p>
              </div>

              <div className="space-y-6">
                {/* Google Sign In */}
                <Button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={isLoading}
                  className="group relative h-12 w-full justify-center rounded-full border border-white/15
                             bg-gradient-to-b from-[#303B70] to-[#1E274A] text-white
                             shadow-[0_14px_34px_rgba(0,0,0,.45),0_0_0_1px_rgba(140,150,210,.18)_inset]
                             hover:brightness-110 active:scale-[.99]"
                >
                  <Chrome className="mr-2 h-5 w-5 opacity-90" />
                  Continue with Google
                  <span className="pointer-events-none absolute inset-0 rounded-full ring-1 ring-white/10" />
                </Button>

                {/* Divider */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-white/10" />
                  </div>
                  <div className="relative flex justify-center text-[11px] uppercase tracking-wider">
                    <span className="bg-transparent px-3 text-slate-400">Or continue with email</span>
                  </div>
                </div>

                {/* Email / Password */}
                <form onSubmit={handleEmailLogin} className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm text-slate-300">Email Address</Label>
                    <div className="relative">
                      <Mail className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                      <input
                        id="email"
                        type="email"
                        placeholder="agent@control-room.ai"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="h-12 w-full rounded-xl border border-white/12 bg-white/[0.04]
                                   pl-12 pr-4 text-[15px] text-white placeholder:text-slate-500
                                   outline-none transition focus:border-indigo-400/40
                                   focus:ring-4 focus:ring-indigo-500/10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-sm text-slate-300">Password</Label>
                    <div className="relative">
                      <Lock className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                      <input
                        id="password"
                        type={showPw ? 'text' : 'password'}
                        placeholder="••••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="h-12 w-full rounded-xl border border-white/12 bg-white/[0.04]
                                   pl-12 pr-12 text-[15px] text-white placeholder:text-slate-500
                                   outline-none transition focus:border-indigo-400/40
                                   focus:ring-4 focus:ring-indigo-500/10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPw((v) => !v)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md px-2 py-1 text-xs
                                   text-slate-300 hover:bg-white/5"
                        aria-label={showPw ? 'Hide password' : 'Show password'}
                      >
                        {showPw ? 'Hide' : 'Show'}
                      </button>
                    </div>
                  </div>

                  {error && (
                    <div className="rounded-lg border border-red-500/25 bg-red-500/10 px-4 py-2 text-center text-sm text-red-300">
                      {error}
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="group relative h-12 w-full justify-center rounded-full border border-white/15
                               bg-gradient-to-b from-[#303B70] to-[#1E274A] text-white font-semibold
                               shadow-[0_14px_34px_rgba(0,0,0,.45),0_0_0_1px_rgba(140,150,210,.18)_inset]
                               hover:brightness-110 active:scale-[.99]"
                  >
                    {isLoading ? 'Accessing…' : 'Sign In'}
                    <span className="pointer-events-none absolute inset-0 rounded-full ring-1 ring-white/10" />
                  </Button>
                </form>

                <p className="text-center text-sm text-slate-400">
                  Don&apos;t have an account?{' '}
                  <Link href="/pricing" className="font-medium text-indigo-300 hover:text-indigo-200">
                    Get started here
                  </Link>
                </p>
              </div>
            </div>
          </div>

          {/* Legal */}
          <p className="mt-6 text-center text-xs text-slate-500">
            By signing in, you agree to our{' '}
            <Link href="/terms" className="text-indigo-300 hover:text-indigo-200">Terms of Service</Link>{' '}
            and{' '}
            <Link href="/privacy" className="text-indigo-300 hover:text-indigo-200">Privacy Policy</Link>
          </p>
        </div>
      </div>
    </>
  )
}

function GlobalStyles() {
  return (
    <style jsx global>{`
      :root {
        --bg-a: #0a0f1e;
        --bg-b: #171c2a;
        --bg-c: #0d1218;
      }
      html, body, #__next {
        height: 100%;
      }
      body {
        margin: 0;
        background: radial-gradient(1200px 600px at 50% -10%, rgba(110,104,220,.12), transparent 60%),
                    radial-gradient(900px 520px at 72% 110%, rgba(60,80,220,.08), transparent 60%),
                    linear-gradient(135deg, var(--bg-a) 0%, var(--bg-b) 50%, var(--bg-c) 100%);
        color: #fff;
        -webkit-font-smoothing: antialiased;
      }
      /* hide scrollbars */
      html::-webkit-scrollbar, body::-webkit-scrollbar { display: none; }
      html { scrollbar-width: none; }
    `}</style>
  )
}
